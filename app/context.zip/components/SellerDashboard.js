// app/seller/dashboard/page.js - UPDATED WITH NOTIFICATIONS
'use client';

import { useState, useEffect } from 'react';
import { getSellerDashboard, getStoreDetails } from '@/lib/auth';
import { useRouter } from 'next/navigation';
import { useOrderSubscription } from '@/app/hooks/useOrderSubscription';
import { useNotifications } from '@/app/context/NotificationContext';
import { supabase } from '@/lib/supabase/client';
import toast from 'react-hot-toast';
import Sidebar from '../components/Sidebar';
import styles from '../components/SellerDashboard.module.css';

export default function SellerDashboard() {
  const router = useRouter();
  const { unreadCount } = useNotifications();
  const [loading, setLoading] = useState(true);
  const [currentTime, setCurrentTime] = useState(new Date());
  const [storeId, setStoreId] = useState(null);
  
  // 🔥 NEW: Real-time order alert
  const [latestOrder, setLatestOrder] = useState(null);
  const [showOrderAlert, setShowOrderAlert] = useState(false);
  
  const [dashboardData, setDashboardData] = useState({
    store: {
      id: null,
      name: '',
      type: '',
      is_open: false
    },
    stats: {
      today_orders: 0,
      today_revenue: 0,
      avg_wait_time: 0,
      completion_rate: 0
    },
    queue: {
      total_in_queue: 0,
      served_today: 0
    }
  });

  const [storeDetails, setStoreDetails] = useState(null);
  const [recentOrders] = useState([]);

  const hourlyData = [
    { hour: '9AM', customers: 5, revenue: 1200 },
    { hour: '10AM', customers: 8, revenue: 2100 },
    { hour: '11AM', customers: 12, revenue: 3200 },
    { hour: '12PM', customers: 15, revenue: 3800 },
    { hour: '1PM', customers: 10, revenue: 2800 },
    { hour: '2PM', customers: 18, revenue: 4500 },
    { hour: '3PM', customers: 7, revenue: 1850 },
  ];

  // Load dashboard data
  useEffect(() => {
    async function loadDashboard() {
      try {
        setLoading(true);
        
        const dashboardResult = await getSellerDashboard();
        
        if (dashboardResult.success) {
          setDashboardData(dashboardResult.data);
          setStoreId(dashboardResult.data.store.id);
        } else {
          console.error('Dashboard load error:', dashboardResult.error);
          router.push('/seller/register');
          return;
        }

        const storeResult = await getStoreDetails();
        if (storeResult.success) {
          setStoreDetails(storeResult.data);
        }
        
      } catch (error) {
        console.error('Dashboard load error:', error);
      } finally {
        setLoading(false);
      }
    }

    loadDashboard();
  }, [router]);

  // 🔥 REAL-TIME ORDER SUBSCRIPTION
  useOrderSubscription(storeId, {
    onNewOrder: (newOrder) => {
      console.log('🎉 Dashboard: New order received!', newOrder);
      
      // Show order alert popup
      setLatestOrder(newOrder);
      setShowOrderAlert(true);
      
      // Auto-hide after 10 seconds
      setTimeout(() => {
        setShowOrderAlert(false);
      }, 10000);
      
      // Update dashboard stats
      setDashboardData(prev => ({
        ...prev,
        stats: {
          ...prev.stats,
          today_orders: prev.stats.today_orders + 1,
          today_revenue: prev.stats.today_revenue + (newOrder.total_amount || 0)
        },
        queue: {
          ...prev.queue,
          total_in_queue: prev.queue.total_in_queue + 1
        }
      }));

      // Show toast
      toast.success(`New Order #${newOrder.order_number}!`, {
        duration: 5000,
        icon: '🎉',
      });
    }
  });

  // Update current time
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (date) => {
    return date.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit',
      second: '2-digit',
      hour12: true 
    });
  };

  const formatDate = (date) => {
    return date.toLocaleDateString('en-US', { 
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const handleQuickAction = (action) => {
    console.log('Quick action:', action);
    
    switch(action) {
      case 'Manage Queue':
        router.push('/seller/queue');
        break;
      case 'Add Product':
        router.push('/seller/products');
        break;
      case 'Issue Token':
        router.push('/seller/queue');
        break;
      case 'View Reports':
        router.push('/seller/analytics');
        break;
      default:
        alert(`Action: ${action}`);
    }
  };

  if (loading) {
    return (
      <div className={styles.dashboard}>
        <Sidebar />
        <main className={styles.mainContent}>
          <div className={styles.loadingContainer}>
            <div className={styles.loader}></div>
            <p>Loading dashboard...</p>
          </div>
        </main>
      </div>
    );
  }

  const maxCustomers = Math.max(...hourlyData.map(d => d.customers));
  const { store, stats, queue } = dashboardData;

  return (
    <div className={styles.dashboard}>
      <Sidebar />

      <main className={styles.mainContent}>
        {/* 🔥 NEW ORDER ALERT POPUP */}
        {showOrderAlert && latestOrder && (
          <div className={styles.orderAlertOverlay}>
            <div className={styles.orderAlertCard}>
              <div className={styles.orderAlertHeader}>
                <h3>🎉 New Order Received!</h3>
                <button 
                  className={styles.orderAlertClose}
                  onClick={() => setShowOrderAlert(false)}
                >
                  ✕
                </button>
              </div>
              <div className={styles.orderAlertBody}>
                <div className={styles.orderAlertInfo}>
                  <div className={styles.orderAlertRow}>
                    <span>Order Number:</span>
                    <strong>#{latestOrder.order_number}</strong>
                  </div>
                  <div className={styles.orderAlertRow}>
                    <span>Amount:</span>
                    <strong className={styles.orderAlertAmount}>
                      ₹{latestOrder.total_amount?.toFixed(2)}
                    </strong>
                  </div>
                  <div className={styles.orderAlertRow}>
                    <span>Items:</span>
                    <strong>{latestOrder.items?.length} items</strong>
                  </div>
                  <div className={styles.orderAlertRow}>
                    <span>Payment:</span>
                    <strong>{latestOrder.payment_method}</strong>
                  </div>
                </div>
              </div>
              <div className={styles.orderAlertActions}>
                <button 
                  className={styles.orderAlertBtnPrimary}
                  onClick={() => {
                    setShowOrderAlert(false);
                    router.push('/seller/orders');
                  }}
                >
                  View Order →
                </button>
                <button 
                  className={styles.orderAlertBtnSecondary}
                  onClick={() => setShowOrderAlert(false)}
                >
                  Dismiss
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Top Bar */}
        <header className={styles.topBar}>
          <div className={styles.topBarLeft}>
            <h1 className={styles.pageTitle}>Dashboard</h1>
            <div className={styles.dateTime}>
              <div className={styles.date}>{formatDate(currentTime)}</div>
              <div className={styles.time}>{formatTime(currentTime)}</div>
            </div>
          </div>
          <div className={styles.topBarRight}>
            <button className={styles.iconButton} onClick={() => router.push('/seller/notifications')}>
              {unreadCount > 0 && <span className={styles.notificationBadge}>{unreadCount}</span>}
              🔔
            </button>
            <button className={styles.iconButton} onClick={() => router.push('/seller/settings')}>
              ⚙️
            </button>
          </div>
        </header>

        {/* Store Status Banner */}
        {store && (
          <div className={`${styles.storeBanner} ${store.is_open ? styles.storeOpen : styles.storeClosed}`}>
            <div className={styles.storeBannerContent}>
              <div className={styles.storeBannerLeft}>
                <h2>{store.name}</h2>
                <span className={styles.storeType}>{store.type}</span>
              </div>
              <div className={styles.storeBannerRight}>
                <span className={styles.storeStatus}>
                  {store.is_open ? '🟢 Open' : '🔴 Closed'}
                </span>
              </div>
            </div>
          </div>
        )}

        {/* Live Queue Alert */}
        <div className={styles.liveAlert}>
          <div className={styles.liveAlertContent}>
            <div className={styles.liveIndicator}>
              <span className={styles.liveDot}></span>
              <span className={styles.liveText}>LIVE QUEUE</span>
            </div>
            <div className={styles.liveStats}>
              <div className={styles.liveStat}>
                <span className={styles.liveStatLabel}>In Queue:</span>
                <span className={styles.liveStatValue}>{queue?.total_in_queue || 0}</span>
              </div>
              <div className={styles.liveStat}>
                <span className={styles.liveStatLabel}>Served Today:</span>
                <span className={styles.liveStatValue}>{queue?.served_today || 0}</span>
              </div>
              <div className={styles.liveStat}>
                <span className={styles.liveStatLabel}>Avg Wait:</span>
                <span className={styles.liveStatValue}>{stats?.avg_wait_time || 0} min</span>
              </div>
            </div>
            <button 
              className={styles.manageQueueBtn}
              onClick={() => handleQuickAction('Manage Queue')}
            >
              Manage Queue →
            </button>
          </div>
        </div>

        {/* Quick Stats Grid */}
        <div className={styles.statsGrid}>
          <div className={`${styles.statCard} ${styles.statCardPrimary}`}>
            <div className={styles.statIcon}>📦</div>
            <div className={styles.statContent}>
              <div className={styles.statLabel}>Today's Orders</div>
              <div className={styles.statValue}>{stats?.today_orders || 0}</div>
              <div className={styles.statChange}>
                <span className={styles.statChangeUp}>↑ 12%</span>
                <span className={styles.statChangeText}>from yesterday</span>
              </div>
            </div>
          </div>

          <div className={`${styles.statCard} ${styles.statCardSuccess}`}>
            <div className={styles.statIcon}>💰</div>
            <div className={styles.statContent}>
              <div className={styles.statLabel}>Today's Revenue</div>
              <div className={styles.statValue}>
                ₹{(stats?.today_revenue || 0).toLocaleString('en-IN')}
              </div>
              <div className={styles.statChange}>
                <span className={styles.statChangeUp}>↑ 18%</span>
                <span className={styles.statChangeText}>from yesterday</span>
              </div>
            </div>
          </div>

          <div className={`${styles.statCard} ${styles.statCardWarning}`}>
            <div className={styles.statIcon}>⏱️</div>
            <div className={styles.statContent}>
              <div className={styles.statLabel}>Avg Wait Time</div>
              <div className={styles.statValue}>{stats?.avg_wait_time || 0} min</div>
              <div className={styles.statChange}>
                <span className={styles.statChangeDown}>↓ 2 min</span>
                <span className={styles.statChangeText}>from yesterday</span>
              </div>
            </div>
          </div>

          <div className={`${styles.statCard} ${styles.statCardInfo}`}>
            <div className={styles.statIcon}>✅</div>
            <div className={styles.statContent}>
              <div className={styles.statLabel}>Completion Rate</div>
              <div className={styles.statValue}>{stats?.completion_rate || 0}%</div>
              <div className={styles.statChange}>
                <span className={styles.statChangeUp}>↑ 3%</span>
                <span className={styles.statChangeText}>from yesterday</span>
              </div>
            </div>
          </div>
        </div>

        {/* Main Content Grid */}
        <div className={styles.contentGrid}>
          {/* Hourly Chart */}
          <div className={styles.chartCard}>
            <div className={styles.cardHeader}>
              <h2 className={styles.cardTitle}>Today's Activity</h2>
              <div className={styles.chartLegend}>
                <span className={styles.legendItem}>
                  <span className={`${styles.legendDot} ${styles.legendDotPrimary}`}></span>
                  Customers
                </span>
              </div>
            </div>
            <div className={styles.chartContainer}>
              {hourlyData.map((data, index) => (
                <div key={index} className={styles.chartBar}>
                  <div 
                    className={styles.barFill}
                    style={{ height: `${(data.customers / maxCustomers) * 100}%` }}
                  >
                    <span className={styles.barValue}>{data.customers}</span>
                  </div>
                  <div className={styles.barLabel}>{data.hour}</div>
                </div>
              ))}
            </div>
          </div>

          {/* Recent Orders */}
          <div className={styles.ordersCard}>
            <div className={styles.cardHeader}>
              <h2 className={styles.cardTitle}>Recent Orders</h2>
              <a href="/seller/orders" className={styles.cardLink}>View All →</a>
            </div>
            <div className={styles.ordersTable}>
              {recentOrders.length === 0 ? (
                <div className={styles.emptyOrders}>
                  <p>No orders yet. Orders will appear here.</p>
                </div>
              ) : (
                recentOrders.map((order) => (
                  <div key={order.id} className={styles.orderRow}>
                    <div className={styles.orderInfo}>
                      <div className={styles.orderCustomer}>{order.customer}</div>
                      <div className={styles.orderDetails}>
                        {order.id} • {order.items} items • {order.time}
                      </div>
                    </div>
                    <div className={styles.orderRight}>
                      <div className={styles.orderAmount}>₹{order.amount}</div>
                      <span className={`${styles.orderStatus} ${
                        order.status === 'completed' ? styles.statusCompleted : styles.statusPreparing
                      }`}>
                        {order.status === 'completed' ? '✓ Completed' : '⏳ Preparing'}
                      </span>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Quick Actions */}
        <div className={styles.actionsSection}>
          <h2 className={styles.sectionTitle}>Quick Actions</h2>
          <div className={styles.actionsGrid}>
            <button 
              className={styles.actionCard}
              onClick={() => handleQuickAction('Add Product')}
            >
              <div className={styles.actionIcon}>📦</div>
              <div className={styles.actionText}>Add Product</div>
            </button>
            <button 
              className={styles.actionCard}
              onClick={() => handleQuickAction('Issue Token')}
            >
              <div className={styles.actionIcon}>🎫</div>
              <div className={styles.actionText}>Issue Token</div>
            </button>
            <button 
              className={styles.actionCard}
              onClick={() => handleQuickAction('Pause Queue')}
            >
              <div className={styles.actionIcon}>⏸️</div>
              <div className={styles.actionText}>Pause Queue</div>
            </button>
            <button 
              className={styles.actionCard}
              onClick={() => handleQuickAction('Send Alert')}
            >
              <div className={styles.actionIcon}>📢</div>
              <div className={styles.actionText}>Send Alert</div>
            </button>
            <button 
              className={styles.actionCard}
              onClick={() => handleQuickAction('View Reports')}
            >
              <div className={styles.actionIcon}>📊</div>
              <div className={styles.actionText}>View Reports</div>
            </button>
            <button 
              className={styles.actionCard}
              onClick={() => router.push('/seller/settings')}
            >
              <div className={styles.actionIcon}>⚙️</div>
              <div className={styles.actionText}>Settings</div>
            </button>
          </div>
        </div>
      </main>
    </div>
  );
}