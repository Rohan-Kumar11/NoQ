'use client';

import { useState, useEffect } from 'react';
import Sidebar from './Sidebar';
import styles from './Payments.module.css';
import { LineChart, Line, BarChart, Bar, PieChart, Pie, Cell, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer } from 'recharts';

export default function Payments() {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [selectedPeriod, setSelectedPeriod] = useState('today');
  const [selectedTab, setSelectedTab] = useState('overview');

  // Financial Summary Data
  const [financialData, setFinancialData] = useState({
    todayRevenue: 12450,
    weekRevenue: 78230,
    monthRevenue: 342890,
    pendingPayouts: 8450,
    completedPayouts: 334440,
    processingPayouts: 2340,
    totalTransactions: 847,
    avgTransactionValue: 405,
  });

  // Recent Transactions
  const [transactions] = useState([
    { 
      id: 'TXN-2024-1847', 
      orderId: 'ORD-1234',
      customer: 'Rahul Sharma', 
      amount: 450, 
      method: 'UPI',
      status: 'completed', 
      time: '2024-01-27 10:45 AM',
      utrNumber: 'UTR402934857234'
    },
    { 
      id: 'TXN-2024-1846', 
      orderId: 'ORD-1233',
      customer: 'Priya Patel', 
      amount: 680, 
      method: 'Card',
      status: 'completed', 
      time: '2024-01-27 10:30 AM',
      utrNumber: 'UTR402934857233'
    },
    { 
      id: 'TXN-2024-1845', 
      orderId: 'ORD-1232',
      customer: 'Amit Kumar', 
      amount: 320, 
      method: 'Cash',
      status: 'completed', 
      time: '2024-01-27 10:15 AM',
      utrNumber: 'CASH-LOCAL'
    },
    { 
      id: 'TXN-2024-1844', 
      orderId: 'ORD-1231',
      customer: 'Sneha Singh', 
      amount: 890, 
      method: 'UPI',
      status: 'processing', 
      time: '2024-01-27 10:00 AM',
      utrNumber: 'UTR402934857231'
    },
    { 
      id: 'TXN-2024-1843', 
      orderId: 'ORD-1230',
      customer: 'Vikram Reddy', 
      amount: 560, 
      method: 'Wallet',
      status: 'completed', 
      time: '2024-01-27 09:45 AM',
      utrNumber: 'WLT402934857230'
    },
    { 
      id: 'TXN-2024-1842', 
      orderId: 'ORD-1229',
      customer: 'Kavita Desai', 
      amount: 1200, 
      method: 'Card',
      status: 'completed', 
      time: '2024-01-27 09:30 AM',
      utrNumber: 'UTR402934857229'
    },
    { 
      id: 'TXN-2024-1841', 
      orderId: 'ORD-1228',
      customer: 'Rohan Mehta', 
      amount: 340, 
      method: 'UPI',
      status: 'failed', 
      time: '2024-01-27 09:15 AM',
      utrNumber: 'N/A'
    },
    { 
      id: 'TXN-2024-1840', 
      orderId: 'ORD-1227',
      customer: 'Anjali Gupta', 
      amount: 780, 
      method: 'Cash',
      status: 'completed', 
      time: '2024-01-27 09:00 AM',
      utrNumber: 'CASH-LOCAL'
    },
  ]);

  // Payout History
  const [payouts] = useState([
    { 
      id: 'PAYOUT-001', 
      amount: 45000, 
      status: 'completed', 
      date: '2024-01-25',
      method: 'Bank Transfer',
      accountLast4: '4523',
      utrNumber: 'UTR987654321234'
    },
    { 
      id: 'PAYOUT-002', 
      amount: 38500, 
      status: 'completed', 
      date: '2024-01-20',
      method: 'Bank Transfer',
      accountLast4: '4523',
      utrNumber: 'UTR987654321233'
    },
    { 
      id: 'PAYOUT-003', 
      amount: 42300, 
      status: 'processing', 
      date: '2024-01-27',
      method: 'Bank Transfer',
      accountLast4: '4523',
      utrNumber: 'Pending'
    },
    { 
      id: 'PAYOUT-004', 
      amount: 51200, 
      status: 'completed', 
      date: '2024-01-15',
      method: 'Bank Transfer',
      accountLast4: '4523',
      utrNumber: 'UTR987654321231'
    },
  ]);

  // Payment Methods Distribution
  const paymentMethods = [
    { method: 'UPI', percentage: 45, amount: 156780, color: '#6366f1' },
    { method: 'Card', percentage: 30, amount: 104580, color: '#8b5cf6' },
    { method: 'Cash', percentage: 15, amount: 52290, color: '#ec4899' },
    { method: 'Wallet', percentage: 10, amount: 34860, color: '#14b8a6' },
  ];

  // Daily Revenue Chart Data
  const dailyRevenueData = [
    { day: 'Mon', revenue: 45000 },
    { day: 'Tue', revenue: 52000 },
    { day: 'Wed', revenue: 48000 },
    { day: 'Thu', revenue: 61000 },
    { day: 'Fri', revenue: 58000 },
    { day: 'Sat', revenue: 72000 },
    { day: 'Sun', revenue: 67000 },
  ];

  // Update current time
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (date) => {
    return date.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit',
      second: '2-digit',
      hour12: true 
    });
  };

  const formatDate = (date) => {
    return date.toLocaleDateString('en-US', { 
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const handleExport = (type) => {
    alert(`Exporting ${type} report...`);
  };

  const handleViewDetails = (transaction) => {
    alert(`Transaction Details:\nID: ${transaction.id}\nOrder: ${transaction.orderId}\nAmount: ₹${transaction.amount}\nUTR: ${transaction.utrNumber}`);
  };

  const maxRevenue = Math.max(...dailyRevenueData.map(d => d.revenue));

  return (
    <div className={styles.dashboard}>
      <Sidebar />

      <main className={styles.mainContent}>
        {/* Top Bar */}
        <header className={styles.topBar}>
          <div className={styles.topBarLeft}>
            <h1 className={styles.pageTitle}>Payments & Payouts</h1>
            <div className={styles.dateTime}>
              <div className={styles.date}>{formatDate(currentTime)}</div>
              <div className={styles.time}>{formatTime(currentTime)}</div>
            </div>
          </div>
          <div className={styles.topBarRight}>
            <button className={styles.exportBtn} onClick={() => handleExport('All')}>
              📥 Export Report
            </button>
            <button className={styles.iconButton}>
              <span className={styles.notificationBadge}>3</span>
              🔔
            </button>
            <button className={styles.iconButton}>⚙️</button>
          </div>
        </header>

        {/* Tab Navigation */}
        <div className={styles.tabNavigation}>
          <button 
            className={`${styles.tabBtn} ${selectedTab === 'overview' ? styles.tabBtnActive : ''}`}
            onClick={() => setSelectedTab('overview')}
          >
            Overview
          </button>
          <button 
            className={`${styles.tabBtn} ${selectedTab === 'transactions' ? styles.tabBtnActive : ''}`}
            onClick={() => setSelectedTab('transactions')}
          >
            Transactions
          </button>
          <button 
            className={`${styles.tabBtn} ${selectedTab === 'payouts' ? styles.tabBtnActive : ''}`}
            onClick={() => setSelectedTab('payouts')}
          >
            Payouts
          </button>
          <button 
            className={`${styles.tabBtn} ${selectedTab === 'methods' ? styles.tabBtnActive : ''}`}
            onClick={() => setSelectedTab('methods')}
          >
            Payment Methods
          </button>
        </div>

        {/* Overview Tab */}
        {selectedTab === 'overview' && (
          <>
            {/* Period Filter */}
            <div className={styles.periodFilter}>
              <button 
                className={`${styles.periodBtn} ${selectedPeriod === 'today' ? styles.periodBtnActive : ''}`}
                onClick={() => setSelectedPeriod('today')}
              >
                Today
              </button>
              <button 
                className={`${styles.periodBtn} ${selectedPeriod === 'week' ? styles.periodBtnActive : ''}`}
                onClick={() => setSelectedPeriod('week')}
              >
                This Week
              </button>
              <button 
                className={`${styles.periodBtn} ${selectedPeriod === 'month' ? styles.periodBtnActive : ''}`}
                onClick={() => setSelectedPeriod('month')}
              >
                This Month
              </button>
            </div>

            {/* Financial Stats */}
            <div className={styles.statsGrid}>
              <div className={`${styles.statCard} ${styles.statCardSuccess}`}>
                <div className={styles.statIcon}>💰</div>
                <div className={styles.statContent}>
                  <div className={styles.statLabel}>
                    {selectedPeriod === 'today' ? "Today's Revenue" : 
                     selectedPeriod === 'week' ? "Week's Revenue" : "Month's Revenue"}
                  </div>
                  <div className={styles.statValue}>
                    ₹{(selectedPeriod === 'today' ? financialData.todayRevenue : 
                        selectedPeriod === 'week' ? financialData.weekRevenue : 
                        financialData.monthRevenue).toLocaleString()}
                  </div>
                  <div className={styles.statChange}>
                    <span className={styles.statChangeUp}>↑ 18%</span>
                    <span className={styles.statChangeText}>from last period</span>
                  </div>
                </div>
              </div>

              <div className={`${styles.statCard} ${styles.statCardWarning}`}>
                <div className={styles.statIcon}>⏳</div>
                <div className={styles.statContent}>
                  <div className={styles.statLabel}>Pending Payouts</div>
                  <div className={styles.statValue}>₹{financialData.pendingPayouts.toLocaleString()}</div>
                  <div className={styles.statChange}>
                    <span className={styles.statChangeText}>2 transactions</span>
                  </div>
                </div>
              </div>

              <div className={`${styles.statCard} ${styles.statCardPrimary}`}>
                <div className={styles.statIcon}>📊</div>
                <div className={styles.statContent}>
                  <div className={styles.statLabel}>Total Transactions</div>
                  <div className={styles.statValue}>{financialData.totalTransactions}</div>
                  <div className={styles.statChange}>
                    <span className={styles.statChangeUp}>↑ 12%</span>
                    <span className={styles.statChangeText}>from yesterday</span>
                  </div>
                </div>
              </div>

              <div className={`${styles.statCard} ${styles.statCardInfo}`}>
                <div className={styles.statIcon}>💳</div>
                <div className={styles.statContent}>
                  <div className={styles.statLabel}>Avg Transaction</div>
                  <div className={styles.statValue}>₹{financialData.avgTransactionValue}</div>
                  <div className={styles.statChange}>
                    <span className={styles.statChangeUp}>↑ 5%</span>
                    <span className={styles.statChangeText}>from last week</span>
                  </div>
                </div>
              </div>
            </div>

            {/* Charts Section */}
            <div className={styles.chartsGrid}>
              {/* Revenue Chart */}
              <div className={styles.chartCard}>
                <div className={styles.cardHeader}>
                  <h2 className={styles.cardTitle}>Weekly Revenue Trend</h2>
                </div>
                <ResponsiveContainer width="100%" height={280}>
                  <LineChart data={dailyRevenueData}>
                    <CartesianGrid strokeDasharray="3 3" stroke="#e0e6ed" />
                    <XAxis dataKey="day" stroke="#6c757d" />
                    <YAxis stroke="#6c757d" />
                    <Tooltip 
                      contentStyle={{ 
                        background: '#ffffff', 
                        border: '1px solid #e0e6ed',
                        borderRadius: '8px'
                      }}
                    />
                    <Line 
                      type="monotone" 
                      dataKey="revenue" 
                      stroke="#667eea" 
                      strokeWidth={3}
                      dot={{ fill: '#667eea', r: 5 }}
                      activeDot={{ r: 7 }}
                    />
                  </LineChart>
                </ResponsiveContainer>
              </div>

              {/* Payment Methods Pie Chart */}
              <div className={styles.methodsCard}>
                <div className={styles.cardHeader}>
                  <h2 className={styles.cardTitle}>Payment Methods Distribution</h2>
                </div>
                <div className={styles.methodsContent}>
                  <ResponsiveContainer width="100%" height={200}>
                    <PieChart>
                      <Pie
                        data={paymentMethods}
                        cx="50%"
                        cy="50%"
                        labelLine={false}
                        outerRadius={80}
                        fill="#8884d8"
                        dataKey="percentage"
                      >
                        {paymentMethods.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.color} />
                        ))}
                      </Pie>
                      <Tooltip />
                    </PieChart>
                  </ResponsiveContainer>
                  <div className={styles.methodsLegend}>
                    {paymentMethods.map((method, index) => (
                      <div key={index} className={styles.legendItem}>
                        <div 
                          className={styles.legendColor} 
                          style={{ backgroundColor: method.color }}
                        ></div>
                        <div className={styles.legendInfo}>
                          <div className={styles.legendLabel}>{method.method}</div>
                          <div className={styles.legendValue}>
                            {method.percentage}% • ₹{method.amount.toLocaleString()}
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              </div>
            </div>

            {/* Quick Summary Cards */}
            <div className={styles.summaryGrid}>
              <div className={styles.summaryCard}>
                <div className={styles.summaryHeader}>
                  <h3 className={styles.summaryTitle}>Completed Payouts</h3>
                  <span className={styles.summaryIcon}>✅</span>
                </div>
                <div className={styles.summaryAmount}>₹{financialData.completedPayouts.toLocaleString()}</div>
                <div className={styles.summaryFooter}>All time</div>
              </div>

              <div className={styles.summaryCard}>
                <div className={styles.summaryHeader}>
                  <h3 className={styles.summaryTitle}>Processing</h3>
                  <span className={styles.summaryIcon}>⏳</span>
                </div>
                <div className={styles.summaryAmount}>₹{financialData.processingPayouts.toLocaleString()}</div>
                <div className={styles.summaryFooter}>In progress</div>
              </div>
            </div>
          </>
        )}

        {/* Transactions Tab */}
        {selectedTab === 'transactions' && (
          <div className={styles.transactionsSection}>
            <div className={styles.transactionsHeader}>
              <h2 className={styles.sectionTitle}>Recent Transactions</h2>
              <div className={styles.transactionsActions}>
                <input 
                  type="text" 
                  className={styles.searchInput} 
                  placeholder="Search by Order ID, Customer..." 
                />
                <button className={styles.filterBtn}>🔍 Filter</button>
                <button className={styles.exportBtn} onClick={() => handleExport('Transactions')}>
                  📥 Export
                </button>
              </div>
            </div>

            <div className={styles.transactionsTable}>
              <div className={styles.tableHeader}>
                <div className={styles.tableCol}>Transaction ID</div>
                <div className={styles.tableCol}>Customer</div>
                <div className={styles.tableCol}>Amount</div>
                <div className={styles.tableCol}>Method</div>
                <div className={styles.tableCol}>Status</div>
                <div className={styles.tableCol}>Time</div>
                <div className={styles.tableCol}>Actions</div>
              </div>
              {transactions.map((txn) => (
                <div key={txn.id} className={styles.tableRow}>
                  <div className={styles.tableCol}>
                    <div className={styles.txnId}>{txn.id}</div>
                    <div className={styles.orderId}>{txn.orderId}</div>
                  </div>
                  <div className={styles.tableCol}>
                    <div className={styles.customerName}>{txn.customer}</div>
                  </div>
                  <div className={styles.tableCol}>
                    <div className={styles.amount}>₹{txn.amount}</div>
                  </div>
                  <div className={styles.tableCol}>
                    <span className={styles.methodBadge}>{txn.method}</span>
                  </div>
                  <div className={styles.tableCol}>
                    <span className={`${styles.statusBadge} ${styles['status' + txn.status.charAt(0).toUpperCase() + txn.status.slice(1)]}`}>
                      {txn.status === 'completed' && '✓ '}
                      {txn.status === 'processing' && '⏳ '}
                      {txn.status === 'failed' && '✗ '}
                      {txn.status.charAt(0).toUpperCase() + txn.status.slice(1)}
                    </span>
                  </div>
                  <div className={styles.tableCol}>
                    <div className={styles.txnTime}>{txn.time}</div>
                  </div>
                  <div className={styles.tableCol}>
                    <button 
                      className={styles.viewBtn}
                      onClick={() => handleViewDetails(txn)}
                    >
                      View
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Payouts Tab */}
        {selectedTab === 'payouts' && (
          <div className={styles.payoutsSection}>
            <div className={styles.payoutsHeader}>
              <h2 className={styles.sectionTitle}>Payout History</h2>
              <div className={styles.payoutsActions}>
                <button className={styles.primaryBtn}>Request Payout</button>
                <button className={styles.exportBtn} onClick={() => handleExport('Payouts')}>
                  📥 Export
                </button>
              </div>
            </div>

            {/* Bank Account Info */}
            <div className={styles.bankInfoCard}>
              <div className={styles.bankInfoHeader}>
                <h3 className={styles.bankInfoTitle}>💳 Linked Bank Account</h3>
                <button className={styles.editBtn}>Edit</button>
              </div>
              <div className={styles.bankInfoContent}>
                <div className={styles.bankDetail}>
                  <span className={styles.bankLabel}>Account Number:</span>
                  <span className={styles.bankValue}>XXXX XXXX 4523</span>
                </div>
                <div className={styles.bankDetail}>
                  <span className={styles.bankLabel}>Bank Name:</span>
                  <span className={styles.bankValue}>HDFC Bank</span>
                </div>
                <div className={styles.bankDetail}>
                  <span className={styles.bankLabel}>IFSC Code:</span>
                  <span className={styles.bankValue}>HDFC0001234</span>
                </div>
                <div className={styles.bankDetail}>
                  <span className={styles.bankLabel}>Account Holder:</span>
                  <span className={styles.bankValue}>NoQ Store Account</span>
                </div>
              </div>
            </div>

            {/* Payouts Table */}
            <div className={styles.payoutsTable}>
              <div className={styles.tableHeader}>
                <div className={styles.tableCol}>Payout ID</div>
                <div className={styles.tableCol}>Amount</div>
                <div className={styles.tableCol}>Date</div>
                <div className={styles.tableCol}>Method</div>
                <div className={styles.tableCol}>Account</div>
                <div className={styles.tableCol}>UTR Number</div>
                <div className={styles.tableCol}>Status</div>
              </div>
              {payouts.map((payout) => (
                <div key={payout.id} className={styles.tableRow}>
                  <div className={styles.tableCol}>
                    <div className={styles.payoutId}>{payout.id}</div>
                  </div>
                  <div className={styles.tableCol}>
                    <div className={styles.payoutAmount}>₹{payout.amount.toLocaleString()}</div>
                  </div>
                  <div className={styles.tableCol}>
                    <div className={styles.payoutDate}>{payout.date}</div>
                  </div>
                  <div className={styles.tableCol}>
                    <span className={styles.methodBadge}>{payout.method}</span>
                  </div>
                  <div className={styles.tableCol}>
                    <div className={styles.accountInfo}>****{payout.accountLast4}</div>
                  </div>
                  <div className={styles.tableCol}>
                    <div className={styles.utrNumber}>{payout.utrNumber}</div>
                  </div>
                  <div className={styles.tableCol}>
                    <span className={`${styles.statusBadge} ${styles['status' + payout.status.charAt(0).toUpperCase() + payout.status.slice(1)]}`}>
                      {payout.status === 'completed' && '✓ '}
                      {payout.status === 'processing' && '⏳ '}
                      {payout.status.charAt(0).toUpperCase() + payout.status.slice(1)}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </div>
        )}

        {/* Payment Methods Tab */}
        {selectedTab === 'methods' && (
          <div className={styles.methodsSection}>
            <h2 className={styles.sectionTitle}>Accepted Payment Methods</h2>
            
            <div className={styles.methodsGrid}>
              <div className={styles.methodCard}>
                <div className={styles.methodCardHeader}>
                  <div className={styles.methodIcon}>📱</div>
                  <h3 className={styles.methodName}>UPI</h3>
                  <span className={styles.methodStatusActive}>Active</span>
                </div>
                <div className={styles.methodStats}>
                  <div className={styles.methodStat}>
                    <span className={styles.methodStatLabel}>This Month:</span>
                    <span className={styles.methodStatValue}>₹156,780</span>
                  </div>
                  <div className={styles.methodStat}>
                    <span className={styles.methodStatLabel}>Transactions:</span>
                    <span className={styles.methodStatValue}>382</span>
                  </div>
                  <div className={styles.methodStat}>
                    <span className={styles.methodStatLabel}>Success Rate:</span>
                    <span className={styles.methodStatValue}>98.5%</span>
                  </div>
                </div>
                <button className={styles.methodBtn}>Configure</button>
              </div>

              <div className={styles.methodCard}>
                <div className={styles.methodCardHeader}>
                  <div className={styles.methodIcon}>💳</div>
                  <h3 className={styles.methodName}>Credit/Debit Card</h3>
                  <span className={styles.methodStatusActive}>Active</span>
                </div>
                <div className={styles.methodStats}>
                  <div className={styles.methodStat}>
                    <span className={styles.methodStatLabel}>This Month:</span>
                    <span className={styles.methodStatValue}>₹104,580</span>
                  </div>
                  <div className={styles.methodStat}>
                    <span className={styles.methodStatLabel}>Transactions:</span>
                    <span className={styles.methodStatValue}>254</span>
                  </div>
                  <div className={styles.methodStat}>
                    <span className={styles.methodStatLabel}>Success Rate:</span>
                    <span className={styles.methodStatValue}>96.2%</span>
                  </div>
                </div>
                <button className={styles.methodBtn}>Configure</button>
              </div>

              <div className={styles.methodCard}>
                <div className={styles.methodCardHeader}>
                  <div className={styles.methodIcon}>💵</div>
                  <h3 className={styles.methodName}>Cash</h3>
                  <span className={styles.methodStatusActive}>Active</span>
                </div>
                <div className={styles.methodStats}>
                  <div className={styles.methodStat}>
                    <span className={styles.methodStatLabel}>This Month:</span>
                    <span className={styles.methodStatValue}>₹52,290</span>
                  </div>
                  <div className={styles.methodStat}>
                    <span className={styles.methodStatLabel}>Transactions:</span>
                    <span className={styles.methodStatValue}>127</span>
                  </div>
                  <div className={styles.methodStat}>
                    <span className={styles.methodStatLabel}>Success Rate:</span>
                    <span className={styles.methodStatValue}>100%</span>
                  </div>
                </div>
                <button className={styles.methodBtn}>Configure</button>
              </div>

              <div className={styles.methodCard}>
                <div className={styles.methodCardHeader}>
                  <div className={styles.methodIcon}>👛</div>
                  <h3 className={styles.methodName}>Digital Wallet</h3>
                  <span className={styles.methodStatusActive}>Active</span>
                </div>
                <div className={styles.methodStats}>
                  <div className={styles.methodStat}>
                    <span className={styles.methodStatLabel}>This Month:</span>
                    <span className={styles.methodStatValue}>₹34,860</span>
                  </div>
                  <div className={styles.methodStat}>
                    <span className={styles.methodStatLabel}>Transactions:</span>
                    <span className={styles.methodStatValue}>84</span>
                  </div>
                  <div className={styles.methodStat}>
                    <span className={styles.methodStatLabel}>Success Rate:</span>
                    <span className={styles.methodStatValue}>97.8%</span>
                  </div>
                </div>
                <button className={styles.methodBtn}>Configure</button>
              </div>
            </div>
          </div>
        )}
      </main>
    </div>
  );
}