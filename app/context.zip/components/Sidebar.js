'use client';

import { usePathname } from 'next/navigation';
import Link from 'next/link';
import styles from './Sidebar.module.css';

export default function Sidebar() {
  const pathname = usePathname();

  const navItems = [
    { href: '/seller/dashboard', icon: '📊', label: 'Dashboard' },
    { href: '/seller/products', icon: '📦', label: 'Products' },
    { href: '/seller/queue', icon: '🎫', label: 'Live Queue' },
    { href: '/seller/orders', icon: '🧾', label: 'Orders' },
    { href: '/seller/payments', icon: '💳', label: 'Payments' },
    { href: '/seller/notifications', icon: '🔔', label: 'Notifications' },
    { href: '/seller/analytics', icon: '📈', label: 'Analytics' },
    { href: '/seller/settings', icon: '⚙️', label: 'Settings' },
  ];

  return (
    <aside className={styles.sidebar}>
      <div className={styles.sidebarHeader}>
        <Link href="/seller/dashboard" className={styles.logo}>
          <span className={styles.logoIcon}>🎫</span>
          <span className={styles.logoText}>NoQ</span>
        </Link>
      </div>

      <nav className={styles.navigation}>
        {navItems.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className={`${styles.navItem} ${pathname === item.href ? styles.navItemActive : ''}`}
          >
            <span className={styles.navIcon}>{item.icon}</span>
            <span className={styles.navText}>{item.label}</span>
          </Link>
        ))}
      </nav>

      <div className={styles.sidebarFooter}>
        <div className={styles.userProfile}>
          <div className={styles.userAvatar}>JS</div>
          <div className={styles.userInfo}>
            <div className={styles.userName}>John's Store</div>
            <div className={styles.userEmail}>Seller Account</div>
          </div>
        </div>
      </div>
    </aside>
  );
}