'use client';

import { useState, useEffect } from 'react';
import Sidebar from './Sidebar';
import styles from './Notifications.module.css';

export default function Notifications() {
  const [currentTime, setCurrentTime] = useState(new Date());
  
  // Notification Settings State
  const [settings, setSettings] = useState({
    // Queue Alerts
    queueAlerts: {
      enabled: true,
      newToken: true,
      tokenApproaching: true,
      queueOverload: true,
      lowQueue: false,
    },
    // Reminder Timing
    reminderTiming: {
      enabled: true,
      beforeMinutes: 5,
      repeatReminder: true,
      repeatInterval: 3,
    },
    // Auto Actions
    autoActions: {
      autoCallNext: false,
      autoCallDelay: 2,
      pauseOnOverload: true,
      overloadThreshold: 15,
    },
    // Delay Messages
    delayMessages: {
      enabled: true,
      autoNotify: true,
      customMessage: 'Your order will be ready shortly. Thank you for your patience!',
    },
    // Notification Channels
    channels: {
      sms: true,
      email: false,
      push: true,
      whatsapp: false,
    },
  });

  // Preview State
  const [previewMessage, setPreviewMessage] = useState({
    type: 'token_ready',
    show: false,
  });

  // Notification Templates
  const templates = {
    token_ready: {
      title: 'Token Ready',
      message: 'Your token {{token_number}} is now being served. Please proceed to the counter.',
      preview: 'Your token A-045 is now being served. Please proceed to the counter.',
    },
    token_approaching: {
      title: 'Token Approaching',
      message: 'Your token {{token_number}} will be called in approximately {{minutes}} minutes.',
      preview: 'Your token A-045 will be called in approximately 5 minutes.',
    },
    order_ready: {
      title: 'Order Ready',
      message: 'Your order for token {{token_number}} is ready for pickup!',
      preview: 'Your order for token A-045 is ready for pickup!',
    },
    delay_notification: {
      title: 'Slight Delay',
      message: settings.delayMessages.customMessage,
      preview: settings.delayMessages.customMessage,
    },
  };

  // Update current time
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  const formatTime = (date) => {
    return date.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit',
      second: '2-digit',
      hour12: true 
    });
  };

  const formatDate = (date) => {
    return date.toLocaleDateString('en-US', { 
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  const handleToggle = (section, field) => {
    setSettings(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [field]: !prev[section][field]
      }
    }));
  };

  const handleNumberChange = (section, field, value) => {
    setSettings(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [field]: parseInt(value) || 0
      }
    }));
  };

  const handleTextChange = (section, field, value) => {
    setSettings(prev => ({
      ...prev,
      [section]: {
        ...prev[section],
        [field]: value
      }
    }));
  };

  const handlePreview = (type) => {
    setPreviewMessage({ type, show: true });
    setTimeout(() => {
      setPreviewMessage({ type, show: false });
    }, 5000);
  };

  const handleSaveSettings = () => {
    // In production, save to backend
    alert('Notification settings saved successfully!');
  };

  const handleTestNotification = () => {
    alert('Test notification sent! Check your registered channels.');
  };

  return (
    <div className={styles.dashboard}>
      <Sidebar />

      <main className={styles.mainContent}>
        {/* Top Bar */}
        <header className={styles.topBar}>
          <div className={styles.topBarLeft}>
            <h1 className={styles.pageTitle}>Notification Control</h1>
            <div className={styles.dateTime}>
              <div className={styles.date}>{formatDate(currentTime)}</div>
              <div className={styles.time}>{formatTime(currentTime)}</div>
            </div>
          </div>
          <div className={styles.topBarRight}>
            <button className={styles.testBtn} onClick={handleTestNotification}>
              📤 Test Notification
            </button>
            <button className={styles.saveBtn} onClick={handleSaveSettings}>
              💾 Save Settings
            </button>
          </div>
        </header>

        {/* Preview Message */}
        {previewMessage.show && (
          <div className={styles.previewAlert}>
            <div className={styles.previewHeader}>
              <span className={styles.previewIcon}>📱</span>
              <span className={styles.previewTitle}>Preview - {templates[previewMessage.type].title}</span>
            </div>
            <div className={styles.previewMessage}>
              {templates[previewMessage.type].preview}
            </div>
          </div>
        )}

        {/* Settings Grid */}
        <div className={styles.settingsGrid}>
          {/* Queue Alerts Section */}
          <div className={styles.settingsCard}>
            <div className={styles.cardHeader}>
              <div className={styles.cardHeaderLeft}>
                <span className={styles.cardIcon}>🔔</span>
                <h2 className={styles.cardTitle}>Queue Alerts</h2>
              </div>
              <div className={styles.masterToggle}>
                <label className={styles.toggleLabel}>
                  <input
                    type="checkbox"
                    checked={settings.queueAlerts.enabled}
                    onChange={() => handleToggle('queueAlerts', 'enabled')}
                    className={styles.toggleInput}
                  />
                  <span className={styles.toggleSlider}></span>
                </label>
              </div>
            </div>

            <div className={styles.cardBody}>
              <div className={styles.settingItem}>
                <div className={styles.settingInfo}>
                  <div className={styles.settingLabel}>New Token Issued</div>
                  <div className={styles.settingDescription}>
                    Notify customers when their token is generated
                  </div>
                </div>
                <label className={styles.toggleLabel}>
                  <input
                    type="checkbox"
                    checked={settings.queueAlerts.newToken}
                    onChange={() => handleToggle('queueAlerts', 'newToken')}
                    disabled={!settings.queueAlerts.enabled}
                    className={styles.toggleInput}
                  />
                  <span className={styles.toggleSlider}></span>
                </label>
              </div>

              <div className={styles.settingItem}>
                <div className={styles.settingInfo}>
                  <div className={styles.settingLabel}>Token Approaching</div>
                  <div className={styles.settingDescription}>
                    Alert when customer's turn is coming up
                  </div>
                </div>
                <label className={styles.toggleLabel}>
                  <input
                    type="checkbox"
                    checked={settings.queueAlerts.tokenApproaching}
                    onChange={() => handleToggle('queueAlerts', 'tokenApproaching')}
                    disabled={!settings.queueAlerts.enabled}
                    className={styles.toggleInput}
                  />
                  <span className={styles.toggleSlider}></span>
                </label>
              </div>

              <div className={styles.settingItem}>
                <div className={styles.settingInfo}>
                  <div className={styles.settingLabel}>Queue Overload Warning</div>
                  <div className={styles.settingDescription}>
                    Alert staff when queue exceeds capacity
                  </div>
                </div>
                <label className={styles.toggleLabel}>
                  <input
                    type="checkbox"
                    checked={settings.queueAlerts.queueOverload}
                    onChange={() => handleToggle('queueAlerts', 'queueOverload')}
                    disabled={!settings.queueAlerts.enabled}
                    className={styles.toggleInput}
                  />
                  <span className={styles.toggleSlider}></span>
                </label>
              </div>

              <div className={styles.settingItem}>
                <div className={styles.settingInfo}>
                  <div className={styles.settingLabel}>Low Queue Alert</div>
                  <div className={styles.settingDescription}>
                    Notify when queue is running low (less than 3)
                  </div>
                </div>
                <label className={styles.toggleLabel}>
                  <input
                    type="checkbox"
                    checked={settings.queueAlerts.lowQueue}
                    onChange={() => handleToggle('queueAlerts', 'lowQueue')}
                    disabled={!settings.queueAlerts.enabled}
                    className={styles.toggleInput}
                  />
                  <span className={styles.toggleSlider}></span>
                </label>
              </div>
            </div>
          </div>

          {/* Reminder Timing Section */}
          <div className={styles.settingsCard}>
            <div className={styles.cardHeader}>
              <div className={styles.cardHeaderLeft}>
                <span className={styles.cardIcon}>⏰</span>
                <h2 className={styles.cardTitle}>Reminder Timing</h2>
              </div>
              <div className={styles.masterToggle}>
                <label className={styles.toggleLabel}>
                  <input
                    type="checkbox"
                    checked={settings.reminderTiming.enabled}
                    onChange={() => handleToggle('reminderTiming', 'enabled')}
                    className={styles.toggleInput}
                  />
                  <span className={styles.toggleSlider}></span>
                </label>
              </div>
            </div>

            <div className={styles.cardBody}>
              <div className={styles.settingItem}>
                <div className={styles.settingInfo}>
                  <div className={styles.settingLabel}>Advance Notice</div>
                  <div className={styles.settingDescription}>
                    How many minutes before to send reminder
                  </div>
                </div>
                <div className={styles.numberInput}>
                  <input
                    type="number"
                    value={settings.reminderTiming.beforeMinutes}
                    onChange={(e) => handleNumberChange('reminderTiming', 'beforeMinutes', e.target.value)}
                    disabled={!settings.reminderTiming.enabled}
                    min="1"
                    max="30"
                    className={styles.inputField}
                  />
                  <span className={styles.inputUnit}>minutes</span>
                </div>
              </div>

              <div className={styles.settingItem}>
                <div className={styles.settingInfo}>
                  <div className={styles.settingLabel}>Repeat Reminder</div>
                  <div className={styles.settingDescription}>
                    Send additional reminders if customer doesn't respond
                  </div>
                </div>
                <label className={styles.toggleLabel}>
                  <input
                    type="checkbox"
                    checked={settings.reminderTiming.repeatReminder}
                    onChange={() => handleToggle('reminderTiming', 'repeatReminder')}
                    disabled={!settings.reminderTiming.enabled}
                    className={styles.toggleInput}
                  />
                  <span className={styles.toggleSlider}></span>
                </label>
              </div>

              {settings.reminderTiming.repeatReminder && (
                <div className={styles.settingItem}>
                  <div className={styles.settingInfo}>
                    <div className={styles.settingLabel}>Repeat Interval</div>
                    <div className={styles.settingDescription}>
                      Time between repeated reminders
                    </div>
                  </div>
                  <div className={styles.numberInput}>
                    <input
                      type="number"
                      value={settings.reminderTiming.repeatInterval}
                      onChange={(e) => handleNumberChange('reminderTiming', 'repeatInterval', e.target.value)}
                      disabled={!settings.reminderTiming.enabled}
                      min="1"
                      max="10"
                      className={styles.inputField}
                    />
                    <span className={styles.inputUnit}>minutes</span>
                  </div>
                </div>
              )}

              <button 
                className={styles.previewBtn}
                onClick={() => handlePreview('token_approaching')}
                disabled={!settings.reminderTiming.enabled}
              >
                👁️ Preview Reminder
              </button>
            </div>
          </div>

          {/* Auto Actions Section */}
          <div className={styles.settingsCard}>
            <div className={styles.cardHeader}>
              <div className={styles.cardHeaderLeft}>
                <span className={styles.cardIcon}>⚡</span>
                <h2 className={styles.cardTitle}>Auto Actions</h2>
              </div>
            </div>

            <div className={styles.cardBody}>
              <div className={styles.settingItem}>
                <div className={styles.settingInfo}>
                  <div className={styles.settingLabel}>Auto-Call Next Token</div>
                  <div className={styles.settingDescription}>
                    Automatically call next customer after serving current
                  </div>
                </div>
                <label className={styles.toggleLabel}>
                  <input
                    type="checkbox"
                    checked={settings.autoActions.autoCallNext}
                    onChange={() => handleToggle('autoActions', 'autoCallNext')}
                    className={styles.toggleInput}
                  />
                  <span className={styles.toggleSlider}></span>
                </label>
              </div>

              {settings.autoActions.autoCallNext && (
                <div className={styles.settingItem}>
                  <div className={styles.settingInfo}>
                    <div className={styles.settingLabel}>Auto-Call Delay</div>
                    <div className={styles.settingDescription}>
                      Wait time before calling next token
                    </div>
                  </div>
                  <div className={styles.numberInput}>
                    <input
                      type="number"
                      value={settings.autoActions.autoCallDelay}
                      onChange={(e) => handleNumberChange('autoActions', 'autoCallDelay', e.target.value)}
                      min="0"
                      max="10"
                      className={styles.inputField}
                    />
                    <span className={styles.inputUnit}>minutes</span>
                  </div>
                </div>
              )}

              <div className={styles.settingItem}>
                <div className={styles.settingInfo}>
                  <div className={styles.settingLabel}>Pause on Overload</div>
                  <div className={styles.settingDescription}>
                    Automatically pause queue when it exceeds threshold
                  </div>
                </div>
                <label className={styles.toggleLabel}>
                  <input
                    type="checkbox"
                    checked={settings.autoActions.pauseOnOverload}
                    onChange={() => handleToggle('autoActions', 'pauseOnOverload')}
                    className={styles.toggleInput}
                  />
                  <span className={styles.toggleSlider}></span>
                </label>
              </div>

              {settings.autoActions.pauseOnOverload && (
                <div className={styles.settingItem}>
                  <div className={styles.settingInfo}>
                    <div className={styles.settingLabel}>Overload Threshold</div>
                    <div className={styles.settingDescription}>
                      Maximum queue size before auto-pause
                    </div>
                  </div>
                  <div className={styles.numberInput}>
                    <input
                      type="number"
                      value={settings.autoActions.overloadThreshold}
                      onChange={(e) => handleNumberChange('autoActions', 'overloadThreshold', e.target.value)}
                      min="5"
                      max="50"
                      className={styles.inputField}
                    />
                    <span className={styles.inputUnit}>tokens</span>
                  </div>
                </div>
              )}
            </div>
          </div>

          {/* Delay Messages Section */}
          <div className={styles.settingsCard}>
            <div className={styles.cardHeader}>
              <div className={styles.cardHeaderLeft}>
                <span className={styles.cardIcon}>💬</span>
                <h2 className={styles.cardTitle}>Delay Messages</h2>
              </div>
              <div className={styles.masterToggle}>
                <label className={styles.toggleLabel}>
                  <input
                    type="checkbox"
                    checked={settings.delayMessages.enabled}
                    onChange={() => handleToggle('delayMessages', 'enabled')}
                    className={styles.toggleInput}
                  />
                  <span className={styles.toggleSlider}></span>
                </label>
              </div>
            </div>

            <div className={styles.cardBody}>
              <div className={styles.settingItem}>
                <div className={styles.settingInfo}>
                  <div className={styles.settingLabel}>Auto-Notify on Delay</div>
                  <div className={styles.settingDescription}>
                    Automatically send message when order is delayed
                  </div>
                </div>
                <label className={styles.toggleLabel}>
                  <input
                    type="checkbox"
                    checked={settings.delayMessages.autoNotify}
                    onChange={() => handleToggle('delayMessages', 'autoNotify')}
                    disabled={!settings.delayMessages.enabled}
                    className={styles.toggleInput}
                  />
                  <span className={styles.toggleSlider}></span>
                </label>
              </div>

              <div className={styles.textInputWrapper}>
                <label className={styles.textLabel}>Custom Delay Message</label>
                <textarea
                  value={settings.delayMessages.customMessage}
                  onChange={(e) => handleTextChange('delayMessages', 'customMessage', e.target.value)}
                  disabled={!settings.delayMessages.enabled}
                  className={styles.textArea}
                  rows={4}
                  placeholder="Enter custom message for delays..."
                />
                <div className={styles.charCount}>
                  {settings.delayMessages.customMessage.length} / 200 characters
                </div>
              </div>

              <button 
                className={styles.previewBtn}
                onClick={() => handlePreview('delay_notification')}
                disabled={!settings.delayMessages.enabled}
              >
                👁️ Preview Message
              </button>
            </div>
          </div>

          {/* Notification Channels Section */}
          <div className={styles.settingsCard}>
            <div className={styles.cardHeader}>
              <div className={styles.cardHeaderLeft}>
                <span className={styles.cardIcon}>📱</span>
                <h2 className={styles.cardTitle}>Notification Channels</h2>
              </div>
            </div>

            <div className={styles.cardBody}>
              <div className={styles.channelGrid}>
                <div className={`${styles.channelCard} ${settings.channels.sms ? styles.channelActive : ''}`}>
                  <div className={styles.channelIcon}>📱</div>
                  <div className={styles.channelName}>SMS</div>
                  <label className={styles.toggleLabel}>
                    <input
                      type="checkbox"
                      checked={settings.channels.sms}
                      onChange={() => handleToggle('channels', 'sms')}
                      className={styles.toggleInput}
                    />
                    <span className={styles.toggleSlider}></span>
                  </label>
                  <div className={styles.channelStatus}>
                    {settings.channels.sms ? 'Active' : 'Inactive'}
                  </div>
                </div>

                <div className={`${styles.channelCard} ${settings.channels.email ? styles.channelActive : ''}`}>
                  <div className={styles.channelIcon}>📧</div>
                  <div className={styles.channelName}>Email</div>
                  <label className={styles.toggleLabel}>
                    <input
                      type="checkbox"
                      checked={settings.channels.email}
                      onChange={() => handleToggle('channels', 'email')}
                      className={styles.toggleInput}
                    />
                    <span className={styles.toggleSlider}></span>
                  </label>
                  <div className={styles.channelStatus}>
                    {settings.channels.email ? 'Active' : 'Inactive'}
                  </div>
                </div>

                <div className={`${styles.channelCard} ${settings.channels.push ? styles.channelActive : ''}`}>
                  <div className={styles.channelIcon}>🔔</div>
                  <div className={styles.channelName}>Push</div>
                  <label className={styles.toggleLabel}>
                    <input
                      type="checkbox"
                      checked={settings.channels.push}
                      onChange={() => handleToggle('channels', 'push')}
                      className={styles.toggleInput}
                    />
                    <span className={styles.toggleSlider}></span>
                  </label>
                  <div className={styles.channelStatus}>
                    {settings.channels.push ? 'Active' : 'Inactive'}
                  </div>
                </div>

                <div className={`${styles.channelCard} ${settings.channels.whatsapp ? styles.channelActive : ''}`}>
                  <div className={styles.channelIcon}>💬</div>
                  <div className={styles.channelName}>WhatsApp</div>
                  <label className={styles.toggleLabel}>
                    <input
                      type="checkbox"
                      checked={settings.channels.whatsapp}
                      onChange={() => handleToggle('channels', 'whatsapp')}
                      className={styles.toggleInput}
                    />
                    <span className={styles.toggleSlider}></span>
                  </label>
                  <div className={styles.channelStatus}>
                    {settings.channels.whatsapp ? 'Active' : 'Inactive'}
                  </div>
                </div>
              </div>
            </div>
          </div>

          {/* Templates Preview Section */}
          <div className={`${styles.settingsCard} ${styles.templatesCard}`}>
            <div className={styles.cardHeader}>
              <div className={styles.cardHeaderLeft}>
                <span className={styles.cardIcon}>📄</span>
                <h2 className={styles.cardTitle}>Notification Templates</h2>
              </div>
            </div>

            <div className={styles.cardBody}>
              <div className={styles.templatesList}>
                {Object.entries(templates).map(([key, template]) => (
                  <div key={key} className={styles.templateItem}>
                    <div className={styles.templateInfo}>
                      <div className={styles.templateTitle}>{template.title}</div>
                      <div className={styles.templateMessage}>{template.message}</div>
                    </div>
                    <button 
                      className={styles.templateBtn}
                      onClick={() => handlePreview(key)}
                    >
                      👁️ Preview
                    </button>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>

        {/* Info Section */}
        <div className={styles.infoSection}>
          <div className={styles.infoCard}>
            <div className={styles.infoIcon}>💡</div>
            <div className={styles.infoContent}>
              <div className={styles.infoTitle}>Pro Tips</div>
              <ul className={styles.infoList}>
                <li>Enable SMS and Push notifications for best customer reach</li>
                <li>Set advance notice to 5-10 minutes for optimal timing</li>
                <li>Use auto-pause on overload during peak hours</li>
                <li>Test notifications regularly to ensure delivery</li>
              </ul>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}