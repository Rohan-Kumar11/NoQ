'use client';

import { useState, useEffect } from 'react';
import Sidebar from './Sidebar';
import styles from './QueueManagement.module.css';
import { supabase } from '@/lib/supabase/client';
import {
  getSellerStoreId,
  getCurrentServingToken,
  getWaitingQueue,
  getQueueStats,
  callNextCustomer,
  markAsServed,
  skipQueueEntry,
  updateQueuePriority,
  moveToFront,
  delayCustomer,
  getStoreSettings,
  toggleStoreStatus,
  updateQueueSettings
} from '@/lib/api/queue';
import toast from 'react-hot-toast';

export default function QueueManagement() {
  const [currentTime, setCurrentTime] = useState(new Date());
  const [loading, setLoading] = useState(true);
  const [storeId, setStoreId] = useState(null);
  const [storeName, setStoreName] = useState('');
  
  // Queue state
  const [queueStatus, setQueueStatus] = useState('active'); // 'active', 'paused'
  const [autoCallNext, setAutoCallNext] = useState(false);
  const [activeToken, setActiveToken] = useState(null);
  const [queueList, setQueueList] = useState([]);
  const [queueStats, setQueueStats] = useState({
    totalInQueue: 0,
    avgWaitTime: 0,
    servedToday: 0,
    cancelledToday: 0,
  });

  // Initialize: Get store and load data
  useEffect(() => {
    initializeQueue();
  }, []);

  // Update current time every second
  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date());
    }, 1000);
    return () => clearInterval(timer);
  }, []);

  // Real-time subscriptions for queue updates
  useEffect(() => {
    if (!storeId) return;

    console.log('Setting up real-time subscriptions for store:', storeId);

    // Subscribe to queue table changes
    const queueChannel = supabase
      .channel(`queue-${storeId}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'queue',
          filter: `store_id=eq.${storeId}`
        },
        (payload) => {
          console.log('Queue update received:', payload);
          handleQueueUpdate(payload);
        }
      )
      .subscribe();

    // Subscribe to orders table changes (linked to queue)
    const ordersChannel = supabase
      .channel(`orders-${storeId}`)
      .on(
        'postgres_changes',
        {
          event: '*',
          schema: 'public',
          table: 'orders',
          filter: `store_id=eq.${storeId}`
        },
        (payload) => {
          console.log('Order update received:', payload);
          // Refresh queue when orders change
          loadQueueData();
        }
      )
      .subscribe();

    return () => {
      supabase.removeChannel(queueChannel);
      supabase.removeChannel(ordersChannel);
    };
  }, [storeId]);

  // Handle real-time queue updates
  const handleQueueUpdate = (payload) => {
    const { eventType, new: newRecord, old: oldRecord } = payload;

    if (eventType === 'INSERT') {
      toast.success('New customer joined the queue!', { icon: '🎫' });
      loadQueueData();
    } else if (eventType === 'UPDATE') {
      if (newRecord.status === 'ready') {
        toast.success(`Token ${newRecord.token_number} is ready!`, { icon: '✅' });
      }
      loadQueueData();
    } else if (eventType === 'DELETE') {
      loadQueueData();
    }
  };

  // Initialize queue management
  const initializeQueue = async () => {
    try {
      setLoading(true);

      // Get seller's store
      const { data: store, error: storeError } = await getSellerStoreId();
      
      if (storeError || !store) {
        toast.error('Failed to load store information');
        setLoading(false);
        return;
      }

      setStoreId(store.id);
      setStoreName(store.store_name || 'Store');

      // Get store settings
      const { data: settings } = await getStoreSettings(store.id);
      if (settings) {
        setAutoCallNext(settings.auto_call_next || false);
        setQueueStatus(settings.is_open ? 'active' : 'paused');
      }

      // Load queue data
      await loadQueueData(store.id);

    } catch (error) {
      console.error('Error initializing queue:', error);
      toast.error('Failed to initialize queue');
    } finally {
      setLoading(false);
    }
  };

  // Load all queue data
  const loadQueueData = async (id = storeId) => {
    if (!id) return;

    try {
      // Load current serving token
      const { data: current } = await getCurrentServingToken(id);
      setActiveToken(current ? formatQueueEntry(current) : null);

      // Load waiting queue
      const { data: waiting } = await getWaitingQueue(id);
      setQueueList(waiting.map(formatQueueEntry));

      // Load queue stats
      const { data: stats } = await getQueueStats(id);
      setQueueStats(stats);

    } catch (error) {
      console.error('Error loading queue data:', error);
    }
  };

  // Format queue entry for display
  const formatQueueEntry = (entry) => {
    const items = entry.order_items || [];
    const order = entry.orders || {};
    
    return {
      id: entry.id,
      tokenNumber: entry.token_number,
      customerName: entry.customer_name || 'Customer',
      customerPhone: entry.customer_phone || '',
      orderItems: items,
      totalAmount: entry.total_amount || 0,
      paymentStatus: order.payment_status || 'paid',
      waitTime: entry.wait_time_minutes || 0,
      orderTime: formatTime(new Date(entry.issued_at)),
      status: entry.status,
      priority: entry.priority || 'normal',
      queueId: entry.id,
      orderId: order.id || null
    };
  };

  // Call next customer
  const handleCallNext = async () => {
    if (!storeId) return;

    try {
      const { data, error } = await callNextCustomer(storeId);
      
      if (error) {
        toast.error(error);
        return;
      }

      if (data) {
        toast.success(`Called ${data.token_number} - ${data.customer_name}`, { icon: '📢' });
        await loadQueueData();
      }
    } catch (error) {
      console.error('Error calling next:', error);
      toast.error('Failed to call next customer');
    }
  };

  // Mark current customer as served
  const handleMarkServed = async () => {
    if (!activeToken) {
      toast.error('No active customer to mark as served');
      return;
    }

    try {
      const { error } = await markAsServed(activeToken.queueId);
      
      if (error) {
        toast.error(error);
        return;
      }

      toast.success(`${activeToken.tokenNumber} marked as served!`, { icon: '✅' });
      
      // If auto-call is enabled, call next automatically
      if (autoCallNext) {
        setTimeout(() => handleCallNext(), 500);
      } else {
        await loadQueueData();
      }
    } catch (error) {
      console.error('Error marking served:', error);
      toast.error('Failed to mark as served');
    }
  };

  // Delay current customer
  const handleDelay = async () => {
    if (!activeToken) return;

    try {
      const { error } = await delayCustomer(activeToken.queueId, storeId, 10);
      
      if (error) {
        toast.error(error);
        return;
      }

      toast.success(`${activeToken.tokenNumber} delayed by 10 minutes`, { icon: '⏱️' });
      await loadQueueData();
      
    } catch (error) {
      console.error('Error delaying customer:', error);
      toast.error('Failed to delay customer');
    }
  };

  // Skip queue entry
  const handleSkipToken = async (queueId, tokenNumber) => {
    if (!window.confirm(`Remove ${tokenNumber} from queue?`)) return;

    try {
      const { error } = await skipQueueEntry(queueId);
      
      if (error) {
        toast.error(error);
        return;
      }

      toast.success(`${tokenNumber} removed from queue`, { icon: '❌' });
      await loadQueueData();
      
    } catch (error) {
      console.error('Error skipping token:', error);
      toast.error('Failed to skip token');
    }
  };

  // Change priority
  const handlePriorityChange = async (queueId, currentPriority) => {
    const newPriority = currentPriority === 'urgent' ? 'normal' : 'urgent';

    try {
      const { error } = await updateQueuePriority(queueId, newPriority);
      
      if (error) {
        toast.error(error);
        return;
      }

      toast.success(`Priority updated to ${newPriority}`, { icon: '⚡' });
      await loadQueueData();
      
    } catch (error) {
      console.error('Error changing priority:', error);
      toast.error('Failed to change priority');
    }
  };

  // Move to front
  const handleMoveToFront = async (queueId, tokenNumber) => {
    try {
      const { error } = await moveToFront(queueId, storeId);
      
      if (error) {
        toast.error(error);
        return;
      }

      toast.success(`${tokenNumber} moved to front`, { icon: '⬆️' });
      await loadQueueData();
      
    } catch (error) {
      console.error('Error moving to front:', error);
      toast.error('Failed to move to front');
    }
  };

  // Pause/Resume queue
  const handlePauseQueue = async () => {
    const newStatus = queueStatus === 'active' ? 'paused' : 'active';
    const isOpen = newStatus === 'active';

    try {
      const { error } = await toggleStoreStatus(storeId, isOpen);
      
      if (error) {
        toast.error(error);
        return;
      }

      setQueueStatus(newStatus);
      toast.success(isOpen ? 'Queue resumed' : 'Queue paused', { 
        icon: isOpen ? '▶️' : '⏸️' 
      });
      
    } catch (error) {
      console.error('Error toggling queue:', error);
      toast.error('Failed to toggle queue');
    }
  };

  // Toggle auto-call next
  const handleAutoCallToggle = async (checked) => {
    try {
      const { error } = await updateQueueSettings(storeId, { autoCallNext: checked });
      
      if (error) {
        toast.error(error);
        return;
      }

      setAutoCallNext(checked);
      toast.success(checked ? 'Auto-call enabled' : 'Auto-call disabled');
      
    } catch (error) {
      console.error('Error updating auto-call:', error);
      toast.error('Failed to update settings');
    }
  };

  // Format time helper
  const formatTime = (date) => {
    return date.toLocaleTimeString('en-US', { 
      hour: '2-digit', 
      minute: '2-digit',
      second: '2-digit',
      hour12: true 
    });
  };

  const formatDate = (date) => {
    return date.toLocaleDateString('en-US', { 
      weekday: 'long',
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
  };

  if (loading) {
    return (
      <div className={styles.dashboard}>
        <Sidebar />
        <main className={styles.mainContent}>
          <div style={{ 
            display: 'flex', 
            justifyContent: 'center', 
            alignItems: 'center', 
            minHeight: '60vh',
            flexDirection: 'column',
            gap: '1rem'
          }}>
            <div style={{ fontSize: '3rem' }}>⏳</div>
            <p style={{ fontSize: '1.2rem', color: '#6b7280' }}>Loading queue management...</p>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className={styles.dashboard}>
      {/* Sidebar Navigation */}
      <Sidebar />

      {/* Main Content */}
      <main className={styles.mainContent}>
        {/* Top Bar */}
        <header className={styles.topBar}>
          <div className={styles.topBarLeft}>
            <h1 className={styles.pageTitle}>Live Queue Management</h1>
            <div className={styles.dateTime}>
              <div className={styles.date}>{formatDate(currentTime)}</div>
              <div className={styles.time}>{formatTime(currentTime)}</div>
            </div>
          </div>
          <div className={styles.topBarRight}>
            <div style={{ 
              background: '#f3f4f6', 
              padding: '0.5rem 1rem', 
              borderRadius: '8px',
              fontWeight: '600',
              color: '#1f2937'
            }}>
              {storeName}
            </div>
          </div>
        </header>

        {/* Queue Status Bar */}
        <div className={`${styles.statusBar} ${queueStatus === 'paused' ? styles.statusBarPaused : ''}`}>
          <div className={styles.statusBarLeft}>
            <div className={styles.statusIndicator}>
              <span className={`${styles.statusDot} ${queueStatus === 'active' ? styles.statusDotActive : styles.statusDotPaused}`}></span>
              <span className={styles.statusText}>
                {queueStatus === 'active' ? 'Queue Active' : 'Queue Paused'}
              </span>
            </div>
            <div className={styles.autoCallToggle}>
              <label className={styles.toggleLabel}>
                <input
                  type="checkbox"
                  checked={autoCallNext}
                  onChange={(e) => handleAutoCallToggle(e.target.checked)}
                  className={styles.toggleInput}
                />
                <span className={styles.toggleSlider}></span>
                <span className={styles.toggleText}>Auto-call next</span>
              </label>
            </div>
          </div>
          <div className={styles.statusBarRight}>
            <button 
              className={`${styles.pauseBtn} ${queueStatus === 'paused' ? styles.resumeBtn : ''}`}
              onClick={handlePauseQueue}
            >
              {queueStatus === 'active' ? '⏸️ Pause Queue' : '▶️ Resume Queue'}
            </button>
          </div>
        </div>

        {/* Queue Stats */}
        <div className={styles.statsGrid}>
          <div className={styles.statCard}>
            <div className={styles.statIcon}>👥</div>
            <div className={styles.statContent}>
              <div className={styles.statLabel}>In Queue</div>
              <div className={styles.statValue}>{queueStats.totalInQueue}</div>
            </div>
          </div>
          <div className={styles.statCard}>
            <div className={styles.statIcon}>⏱️</div>
            <div className={styles.statContent}>
              <div className={styles.statLabel}>Avg Wait Time</div>
              <div className={styles.statValue}>{queueStats.avgWaitTime} min</div>
            </div>
          </div>
          <div className={styles.statCard}>
            <div className={styles.statIcon}>✅</div>
            <div className={styles.statContent}>
              <div className={styles.statLabel}>Served Today</div>
              <div className={styles.statValue}>{queueStats.servedToday}</div>
            </div>
          </div>
          <div className={styles.statCard}>
            <div className={styles.statIcon}>❌</div>
            <div className={styles.statContent}>
              <div className={styles.statLabel}>Cancelled Today</div>
              <div className={styles.statValue}>{queueStats.cancelledToday}</div>
            </div>
          </div>
        </div>

        {/* Main Queue Grid */}
        <div className={styles.queueGrid}>
          {/* Current Serving Section */}
          <div className={styles.currentServing}>
            <div className={styles.sectionHeader}>
              <h2 className={styles.sectionTitle}>Now Serving</h2>
              <span className={styles.servingBadge}>🔴 LIVE</span>
            </div>

            {activeToken ? (
              <div className={styles.activeTokenCard}>
                <div className={styles.tokenHeader}>
                  <div className={styles.tokenNumberLarge}>{activeToken.tokenNumber}</div>
                  <div className={styles.tokenStatus}>
                    <span className={styles.statusBadge}>Serving</span>
                    <span className={styles.waitTimeBadge}>
                      ⏱️ {activeToken.waitTime} min
                    </span>
                  </div>
                </div>

                <div className={styles.customerInfo}>
                  <div className={styles.customerName}>
                    <span className={styles.customerIcon}>👤</span>
                    {activeToken.customerName}
                  </div>
                  {activeToken.customerPhone && (
                    <div className={styles.customerPhone}>
                      📞 {activeToken.customerPhone}
                    </div>
                  )}
                  <div className={styles.orderTime}>
                    🕐 Ordered at {activeToken.orderTime}
                  </div>
                </div>

                <div className={styles.orderDetails}>
                  <div className={styles.orderHeader}>
                    <h3 className={styles.orderTitle}>Order Summary</h3>
                    <span className={`${styles.paymentBadge} ${
                      activeToken.paymentStatus === 'paid' ? styles.paymentPaid : styles.paymentPending
                    }`}>
                      {activeToken.paymentStatus === 'paid' ? '✓ Paid' : '⏳ Pending'}
                    </span>
                  </div>

                  <div className={styles.orderItems}>
                    {activeToken.orderItems.map((item, index) => (
                      <div key={index} className={styles.orderItem}>
                        <div className={styles.itemInfo}>
                          <span className={styles.itemName}>{item.name}</span>
                          <span className={styles.itemQty}>x{item.quantity}</span>
                        </div>
                        <div className={styles.itemPrice}>₹{item.price * item.quantity}</div>
                      </div>
                    ))}
                  </div>

                  <div className={styles.orderTotal}>
                    <span className={styles.totalLabel}>Total Amount</span>
                    <span className={styles.totalValue}>₹{activeToken.totalAmount}</span>
                  </div>
                </div>

                <div className={styles.actionButtons}>
                  <button 
                    className={`${styles.actionBtn} ${styles.actionBtnSuccess}`}
                    onClick={handleMarkServed}
                  >
                    <span className={styles.btnIcon}>✓</span>
                    Mark as Served
                  </button>
                  <button 
                    className={`${styles.actionBtn} ${styles.actionBtnWarning}`}
                    onClick={handleDelay}
                  >
                    <span className={styles.btnIcon}>⏱️</span>
                    Delay
                  </button>
                  <button 
                    className={`${styles.actionBtn} ${styles.actionBtnPrimary}`}
                    onClick={handleCallNext}
                    disabled={queueList.length === 0}
                  >
                    <span className={styles.btnIcon}>📢</span>
                    Call Next
                  </button>
                </div>
              </div>
            ) : (
              <div className={styles.emptyQueue}>
                <div className={styles.emptyIcon}>👋</div>
                <div className={styles.emptyText}>No customer being served</div>
                <div className={styles.emptySubtext}>
                  {queueList.length > 0 ? 'Click "Call Next" to serve the next customer' : 'Waiting for customers...'}
                </div>
                {queueList.length > 0 && (
                  <button 
                    className={`${styles.actionBtn} ${styles.actionBtnPrimary}`}
                    onClick={handleCallNext}
                    style={{ marginTop: '1rem' }}
                  >
                    <span className={styles.btnIcon}>📢</span>
                    Call Next Customer
                  </button>
                )}
              </div>
            )}
          </div>

          {/* Queue List Section */}
          <div className={styles.queueList}>
            <div className={styles.sectionHeader}>
              <h2 className={styles.sectionTitle}>Waiting Queue</h2>
              <span className={styles.queueCount}>{queueList.length} in queue</span>
            </div>

            <div className={styles.queueItems}>
              {queueList.length === 0 ? (
                <div className={styles.emptyQueue}>
                  <div className={styles.emptyIcon}>🎉</div>
                  <div className={styles.emptyText}>No customers in queue</div>
                  <div className={styles.emptySubtext}>You're all caught up!</div>
                </div>
              ) : (
                queueList.map((token, index) => (
                  <div 
                    key={token.id} 
                    className={`${styles.queueCard} ${token.priority === 'urgent' ? styles.queueCardUrgent : ''}`}
                  >
                    <div className={styles.queueCardHeader}>
                      <div className={styles.queueTokenInfo}>
                        <div className={styles.queuePosition}>#{index + 1}</div>
                        <div className={styles.queueTokenNumber}>{token.tokenNumber}</div>
                        {token.priority === 'urgent' && (
                          <span className={styles.urgentBadge}>⚡ URGENT</span>
                        )}
                      </div>
                      <div className={styles.queueWaitTime}>
                        ⏱️ {token.waitTime} min
                      </div>
                    </div>

                    <div className={styles.queueCardBody}>
                      <div className={styles.queueCustomerName}>
                        👤 {token.customerName}
                      </div>
                      <div className={styles.queueOrderInfo}>
                        <span className={styles.queueOrderItems}>
                          📦 {token.orderItems.length} items
                        </span>
                        <span className={styles.queueOrderAmount}>
                          ₹{token.totalAmount}
                        </span>
                        <span className={`${styles.queuePaymentStatus} ${
                          token.paymentStatus === 'paid' ? styles.queuePaymentPaid : styles.queuePaymentPending
                        }`}>
                          {token.paymentStatus === 'paid' ? '✓ Paid' : '⏳ Pending'}
                        </span>
                      </div>
                      <div className={styles.queueOrderTime}>
                        🕐 {token.orderTime}
                      </div>
                    </div>

                    <div className={styles.queueCardActions}>
                      <button 
                        className={styles.queueActionBtn}
                        onClick={() => handlePriorityChange(token.queueId, token.priority)}
                        title="Toggle priority"
                      >
                        {token.priority === 'urgent' ? '⬇️' : '⚡'}
                      </button>
                      <button 
                        className={styles.queueActionBtn}
                        onClick={() => handleSkipToken(token.queueId, token.tokenNumber)}
                        title="Remove from queue"
                      >
                        ❌
                      </button>
                      <button 
                        className={`${styles.queueActionBtn} ${styles.queueActionBtnPrimary}`}
                        onClick={() => handleMoveToFront(token.queueId, token.tokenNumber)}
                        title="Move to front"
                      >
                        ⬆️ Priority
                      </button>
                    </div>
                  </div>
                ))
              )}
            </div>
          </div>
        </div>

        {/* Quick Info Section */}
        <div className={styles.quickInfo}>
          <div className={styles.infoCard}>
            <div className={styles.infoIcon}>💡</div>
            <div className={styles.infoContent}>
              <div className={styles.infoTitle}>Quick Tips</div>
              <ul className={styles.infoList}>
                <li>Use "Auto-call next" to automatically serve next customer</li>
                <li>Mark urgent tokens with ⚡ for priority service</li>
                <li>Pause queue during breaks to prevent new tokens</li>
                <li>Queue updates automatically when new orders arrive</li>
              </ul>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}