'use client';

import { useState, useEffect } from 'react';
import { supabase } from '@/lib/supabase';
import { getCategoryConfig, getProductEmoji } from '@/lib/categoryConfig';
import Sidebar from './Sidebar';
import styles from './ProductManagement.module.css';

export default function DynamicProductManagement() {
  const [storeType, setStoreType] = useState('restaurant');
  const [storeId, setStoreId] = useState(null);
  const [config, setConfig] = useState(null);
  const [products, setProducts] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);
  
  const [searchQuery, setSearchQuery] = useState('');
  const [filterCategory, setFilterCategory] = useState('all');
  const [filterStatus, setFilterStatus] = useState('all');
  const [showAddModal, setShowAddModal] = useState(false);
  const [showEditModal, setShowEditModal] = useState(false);
  const [editingProduct, setEditingProduct] = useState(null);
  const [activeDropdown, setActiveDropdown] = useState(null);

  const [formData, setFormData] = useState({
    name: '',
    category: '',
    price: '',
    stock: '',
    lowStockThreshold: 10,
    status: 'available',
    image: '📦'
  });

  const [errors, setErrors] = useState({});

  // Fetch store details and products on mount
  useEffect(() => {
    fetchStoreDetails();
  }, []);

  // Update config when store type changes
  useEffect(() => {
    if (storeType) {
      const newConfig = getCategoryConfig(storeType);
      setConfig(newConfig);
    }
  }, [storeType]);

  const fetchStoreDetails = async () => {
    try {
      setError(null);
      
      // Get current user
      const { data: { user }, error: userError } = await supabase.auth.getUser();
      
      if (userError) {
        console.error('Auth error:', userError);
        throw new Error('Not authenticated. Please log in.');
      }
      
      if (!user) {
        throw new Error('No user found. Please log in.');
      }

      console.log('Current user ID:', user.id);

      // FIXED: Query stores without .single() to handle multiple stores
      const { data: stores, error: storeError } = await supabase
        .from('stores')
        .select('id, store_type, store_name, is_active')
        .eq('business_id', user.id)
        .order('created_at', { ascending: false });

      if (storeError) {
        console.error('Store query error:', storeError);
        throw new Error(`Failed to fetch stores: ${storeError.message}`);
      }

      console.log('Stores found:', stores);

      // Handle no stores
      if (!stores || stores.length === 0) {
        throw new Error('No store found. Please complete store registration first.');
      }

      // Handle multiple stores - use the first active store or just the first one
      let selectedStore = stores.find(s => s.is_active) || stores[0];
      
      console.log('Selected store:', selectedStore);

      setStoreId(selectedStore.id);
      
      // Use store_type
      const type = (selectedStore.store_type || 'restaurant').toLowerCase();
      setStoreType(type);

      // Fetch products
      await fetchProducts(selectedStore.id);
    } catch (error) {
      console.error('Error in fetchStoreDetails:', error);
      setError(error.message);
    } finally {
      setLoading(false);
    }
  };

  const fetchProducts = async (id) => {
    try {
      const { data, error } = await supabase
        .from('products')
        .select('*')
        .eq('store_id', id)
        .order('created_at', { ascending: false });

      if (error) {
        console.error('Products fetch error:', error);
        throw error;
      }

      console.log('Products fetched:', data?.length || 0);
      setProducts(data || []);
    } catch (error) {
      console.error('Error fetching products:', error);
      setProducts([]);
    }
  };

  const filteredProducts = products.filter(product => {
    const matchesSearch = product.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                         product.category.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = filterCategory === 'all' || product.category === filterCategory;
    const matchesStatus = filterStatus === 'all' || product.status === filterStatus;
    return matchesSearch && matchesCategory && matchesStatus;
  });

  const totalProducts = products.length;
  const availableProducts = products.filter(p => p.status === 'available').length;
  const lowStockProducts = products.filter(p => p.stock > 0 && p.stock <= (p.low_stock_threshold || 10)).length;
  const outOfStockProducts = products.filter(p => p.stock === 0).length;
  const totalValue = products.reduce((sum, p) => sum + (p.price * p.stock), 0);

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
    if (errors[name]) {
      setErrors(prev => ({ ...prev, [name]: '' }));
    }
  };

  const handleMultiselectChange = (fieldName, value) => {
    const currentValues = formData[fieldName] || [];
    const newValues = currentValues.includes(value)
      ? currentValues.filter(v => v !== value)
      : [...currentValues, value];
    
    setFormData(prev => ({
      ...prev,
      [fieldName]: newValues
    }));
  };

  const validateForm = () => {
    const newErrors = {};
    if (!formData.name?.trim()) newErrors.name = 'Name is required';
    if (!formData.category) newErrors.category = 'Category is required';
    if (!formData.price || parseFloat(formData.price) <= 0) newErrors.price = 'Valid price is required';
    if (formData.stock === '' || parseInt(formData.stock) < 0) newErrors.stock = 'Valid stock is required';

    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleAddProduct = async () => {
    if (!validateForm()) return;

    try {
      const productData = {
        store_id: storeId,
        name: formData.name,
        category: formData.category,
        price: parseFloat(formData.price),
        stock: parseInt(formData.stock),
        low_stock_threshold: parseInt(formData.lowStockThreshold) || 10,
        status: parseInt(formData.stock) > 0 ? 'available' : 'unavailable',
        image: getProductEmoji(formData.category, storeType),
        metadata: {}
      };

      // Add specific fields based on store type
      if (config?.fields?.specific) {
        config.fields.specific.forEach(field => {
          if (formData[field.name] !== undefined && formData[field.name] !== '') {
            productData.metadata[field.name] = formData[field.name];
          }
        });
      }

      const { data, error } = await supabase
        .from('products')
        .insert([productData])
        .select()
        .single();

      if (error) throw error;

      setProducts(prev => [data, ...prev]);
      setShowAddModal(false);
      resetForm();
      alert('Product added successfully!');
    } catch (error) {
      console.error('Error adding product:', error);
      alert('Failed to add product: ' + error.message);
    }
  };

  const handleEditProduct = async () => {
    if (!validateForm()) return;

    try {
      const updates = {
        name: formData.name,
        category: formData.category,
        price: parseFloat(formData.price),
        stock: parseInt(formData.stock),
        low_stock_threshold: parseInt(formData.lowStockThreshold) || 10,
        status: parseInt(formData.stock) > 0 ? 'available' : 'unavailable',
        metadata: {}
      };

      // Add specific fields
      if (config?.fields?.specific) {
        config.fields.specific.forEach(field => {
          if (formData[field.name] !== undefined && formData[field.name] !== '') {
            updates.metadata[field.name] = formData[field.name];
          }
        });
      }

      const { error } = await supabase
        .from('products')
        .update(updates)
        .eq('id', editingProduct.id);

      if (error) throw error;

      setProducts(prev => prev.map(p => 
        p.id === editingProduct.id ? { ...p, ...updates } : p
      ));

      setShowEditModal(false);
      setEditingProduct(null);
      resetForm();
      alert('Product updated successfully!');
    } catch (error) {
      console.error('Error updating product:', error);
      alert('Failed to update product: ' + error.message);
    }
  };

  const handleDeleteProduct = async (id) => {
    if (!confirm('Are you sure you want to delete this product?')) return;

    try {
      const { error } = await supabase
        .from('products')
        .delete()
        .eq('id', id);

      if (error) throw error;

      setProducts(prev => prev.filter(p => p.id !== id));
      setActiveDropdown(null);
      alert('Product deleted successfully!');
    } catch (error) {
      console.error('Error deleting product:', error);
      alert('Failed to delete product: ' + error.message);
    }
  };

  const toggleProductStatus = async (id) => {
    const product = products.find(p => p.id === id);
    if (!product) return;

    const newStatus = product.status === 'available' ? 'unavailable' : 'available';

    try {
      const { error } = await supabase
        .from('products')
        .update({ status: newStatus })
        .eq('id', id);

      if (error) throw error;

      setProducts(prev => prev.map(p => 
        p.id === id ? { ...p, status: newStatus } : p
      ));
    } catch (error) {
      console.error('Error updating product status:', error);
      alert('Failed to update status: ' + error.message);
    }
  };

  const openEditModal = (product) => {
    setEditingProduct(product);
    const newFormData = {
      name: product.name,
      category: product.category,
      price: product.price,
      stock: product.stock,
      lowStockThreshold: product.low_stock_threshold || 10,
      status: product.status,
      image: product.image
    };

    // Load metadata fields
    if (product.metadata) {
      Object.keys(product.metadata).forEach(key => {
        newFormData[key] = product.metadata[key];
      });
    }

    setFormData(newFormData);
    setShowEditModal(true);
    setActiveDropdown(null);
  };

  const resetForm = () => {
    const defaultForm = {
      name: '',
      category: '',
      price: '',
      stock: '',
      lowStockThreshold: 10,
      status: 'available',
      image: '📦'
    };

    // Reset specific fields
    if (config?.fields?.specific) {
      config.fields.specific.forEach(field => {
        if (field.type === 'checkbox') {
          defaultForm[field.name] = false;
        } else if (field.type === 'multiselect') {
          defaultForm[field.name] = [];
        } else {
          defaultForm[field.name] = '';
        }
      });
    }

    setFormData(defaultForm);
    setErrors({});
  };

  const categories = config?.categories || ['Products'];

  if (loading) {
    return (
      <div className={styles.dashboard}>
        <Sidebar />
        <main className={styles.mainContent}>
          <div className={styles.loading}>
            <div style={{ textAlign: 'center' }}>
              <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>⏳</div>
              <div>Loading your products...</div>
            </div>
          </div>
        </main>
      </div>
    );
  }

  if (error) {
    return (
      <div className={styles.dashboard}>
        <Sidebar />
        <main className={styles.mainContent}>
          <div className={styles.error}>
            <div style={{ textAlign: 'center', padding: '2rem' }}>
              <div style={{ fontSize: '3rem', marginBottom: '1rem' }}>⚠️</div>
              <h2 style={{ marginBottom: '1rem' }}>Error Loading Products</h2>
              <p style={{ marginBottom: '1.5rem', color: '#64748B' }}>{error}</p>
              <button 
                onClick={() => { setLoading(true); setError(null); fetchStoreDetails(); }}
                className={styles.btnPrimary}
              >
                Try Again
              </button>
            </div>
          </div>
        </main>
      </div>
    );
  }

  if (!config) {
    return (
      <div className={styles.dashboard}>
        <Sidebar />
        <main className={styles.mainContent}>
          <div className={styles.error}>Unable to load product configuration</div>
        </main>
      </div>
    );
  }

  return (
    <div className={styles.dashboard}>
      <Sidebar />

      <main className={styles.mainContent}>
        <div className={styles.container}>
          {/* Header */}
          <div className={styles.header} style={{ background: `linear-gradient(135deg, ${config.color}15 0%, ${config.color}05 100%)` }}>
            <div className={styles.headerContent}>
              <div className={styles.headerTop}>
                <div className={styles.headerTitle}>
                  <h1 className={styles.title}>
                    <span style={{ marginRight: '0.5rem' }}>{config.icon}</span>
                    {config.name} Products
                  </h1>
                  <p className={styles.subtitle}>Manage your {config.name.toLowerCase()} inventory</p>
                </div>
                <div className={styles.headerActions}>
                  <button onClick={() => setShowAddModal(true)} className={styles.btnPrimary} style={{ background: config.gradient }}>
                    <svg className={styles.icon} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                      <line x1="12" y1="5" x2="12" y2="19"></line>
                      <line x1="5" y1="12" x2="19" y2="12"></line>
                    </svg>
                    Add Product
                  </button>
                </div>
              </div>

              {/* Stats Cards */}
              <div className={styles.statsGrid}>
                <div className={`${styles.statCard} ${styles.statBlue}`}>
                  <div className={styles.statIcon}>📦</div>
                  <div className={styles.statValue}>{totalProducts}</div>
                  <div className={styles.statLabel}>Total Products</div>
                </div>
                <div className={`${styles.statCard} ${styles.statGreen}`}>
                  <div className={styles.statIcon}>✓</div>
                  <div className={styles.statValue}>{availableProducts}</div>
                  <div className={styles.statLabel}>Available</div>
                </div>
                <div className={`${styles.statCard} ${styles.statAmber}`}>
                  <div className={styles.statIcon}>⚠️</div>
                  <div className={styles.statValue}>{lowStockProducts}</div>
                  <div className={styles.statLabel}>Low Stock</div>
                </div>
                <div className={`${styles.statCard} ${styles.statRed}`}>
                  <div className={styles.statIcon}>✗</div>
                  <div className={styles.statValue}>{outOfStockProducts}</div>
                  <div className={styles.statLabel}>Out of Stock</div>
                </div>
                <div className={`${styles.statCard} ${styles.statPurple}`}>
                  <div className={styles.statIcon}>₹</div>
                  <div className={styles.statValue}>₹{totalValue.toLocaleString()}</div>
                  <div className={styles.statLabel}>Inventory Value</div>
                </div>
              </div>

              {/* Search and Filters */}
              <div className={styles.searchFilters}>
                <div className={styles.searchBox}>
                  <svg className={styles.searchIcon} viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
                    <circle cx="11" cy="11" r="8"></circle>
                    <path d="m21 21-4.35-4.35"></path>
                  </svg>
                  <input
                    type="text"
                    placeholder="Search products..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className={styles.searchInput}
                  />
                </div>
                <select value={filterCategory} onChange={(e) => setFilterCategory(e.target.value)} className={styles.filterSelect}>
                  <option value="all">All Categories</option>
                  {categories.map(cat => (
                    <option key={cat} value={cat}>{cat}</option>
                  ))}
                </select>
                <select value={filterStatus} onChange={(e) => setFilterStatus(e.target.value)} className={styles.filterSelect}>
                  <option value="all">All Status</option>
                  <option value="available">Available</option>
                  <option value="unavailable">Unavailable</option>
                </select>
              </div>
            </div>
          </div>

          {/* Products Grid */}
          <div className={styles.content}>
            {lowStockProducts > 0 && (
              <div className={styles.alertBox}>
                <span className={styles.alertIcon}>⚠️</span>
                <div>
                  <h3 className={styles.alertTitle}>Low Stock Alert</h3>
                  <p className={styles.alertText}>
                    {lowStockProducts} product{lowStockProducts > 1 ? 's are' : ' is'} running low on stock.
                  </p>
                </div>
              </div>
            )}

            <div className={styles.productsGrid}>
              {filteredProducts.map(product => (
                <div key={product.id} className={styles.productCard}>
                  <div className={styles.productHeader} style={{ background: config.gradient }}>
                    <div className={styles.productEmoji}>{product.image || getProductEmoji(product.category, storeType)}</div>
                    <div className={styles.productMenu}>
                      <button onClick={() => setActiveDropdown(activeDropdown === product.id ? null : product.id)} className={styles.menuBtn}>⋮</button>
                      {activeDropdown === product.id && (
                        <div className={styles.dropdown}>
                          <button onClick={() => openEditModal(product)} className={styles.dropdownItem}>✏️ Edit Product</button>
                          <button onClick={() => handleDeleteProduct(product.id)} className={`${styles.dropdownItem} ${styles.dropdownDanger}`}>🗑️ Delete</button>
                        </div>
                      )}
                    </div>
                  </div>
                  <div className={styles.productBody}>
                    <h3 className={styles.productName}>{product.name}</h3>
                    <span className={styles.productCategory} style={{ background: `${config.color}20`, color: config.color }}>{product.category}</span>
                    <div className={styles.productStats}>
                      <div>
                        <div className={styles.productPrice}>₹{product.price}</div>
                      </div>
                      <div className={styles.productStockBox}>
                        <div className={`${styles.productStock} ${product.stock === 0 ? styles.stockOut : product.stock <= (product.low_stock_threshold || 10) ? styles.stockLow : styles.stockGood}`}>
                          {product.stock}
                        </div>
                        <div className={styles.productSales}>in stock</div>
                      </div>
                    </div>
                    {product.stock > 0 && product.stock <= (product.low_stock_threshold || 10) && (
                      <div className={styles.warningBox}>⚠️ <span>Low stock!</span></div>
                    )}
                    {product.stock === 0 && (
                      <div className={styles.dangerBox}>✗ <span>Out of stock</span></div>
                    )}
                    <button onClick={() => toggleProductStatus(product.id)} className={product.status === 'available' ? styles.btnAvailable : styles.btnUnavailable}>
                      {product.status === 'available' ? '✓ Available' : '✗ Unavailable'}
                    </button>
                  </div>
                </div>
              ))}
            </div>

            {filteredProducts.length === 0 && (
              <div className={styles.emptyState}>
                <div className={styles.emptyIcon}>{config.icon}</div>
                <h3 className={styles.emptyTitle}>No products found</h3>
                <p className={styles.emptyText}>Try adjusting your search or filters, or add a new product</p>
              </div>
            )}
          </div>

          {/* Add Product Modal */}
          {showAddModal && (
            <ProductModal
              config={config}
              formData={formData}
              errors={errors}
              onInputChange={handleInputChange}
              onMultiselectChange={handleMultiselectChange}
              onSubmit={handleAddProduct}
              onClose={() => { setShowAddModal(false); resetForm(); }}
              title="Add New Product"
              submitText="Add Product"
            />
          )}

          {/* Edit Product Modal */}
          {showEditModal && (
            <ProductModal
              config={config}
              formData={formData}
              errors={errors}
              onInputChange={handleInputChange}
              onMultiselectChange={handleMultiselectChange}
              onSubmit={handleEditProduct}
              onClose={() => { setShowEditModal(false); setEditingProduct(null); resetForm(); }}
              title="Edit Product"
              submitText="Save Changes"
            />
          )}
        </div>
      </main>
    </div>
  );
}

// Product Modal Component
function ProductModal({ config, formData, errors, onInputChange, onMultiselectChange, onSubmit, onClose, title, submitText }) {
  const renderField = (field) => {
    switch (field.type) {
      case 'text':
      case 'number':
      case 'date':
        return (
          <input
            type={field.type}
            name={field.name}
            value={formData[field.name] || ''}
            onChange={onInputChange}
            className={`${styles.formInput} ${errors[field.name] ? styles.inputError : ''}`}
            placeholder={field.placeholder}
          />
        );

      case 'select':
        return (
          <select
            name={field.name}
            value={formData[field.name] || ''}
            onChange={onInputChange}
            className={`${styles.formInput} ${errors[field.name] ? styles.inputError : ''}`}
          >
            <option value="">Select {field.label}</option>
            {field.options.map(opt => (
              <option key={opt} value={opt}>{opt}</option>
            ))}
          </select>
        );

      case 'multiselect':
        return (
          <div className={styles.multiselectContainer}>
            {field.options.map(opt => (
              <button
                key={opt}
                type="button"
                onClick={() => onMultiselectChange(field.name, opt)}
                className={`${styles.multiselectOption} ${
                  (formData[field.name] || []).includes(opt) ? styles.multiselectActive : ''
                }`}
              >
                {opt}
              </button>
            ))}
          </div>
        );

      case 'textarea':
        return (
          <textarea
            name={field.name}
            value={formData[field.name] || ''}
            onChange={onInputChange}
            className={`${styles.formTextarea} ${errors[field.name] ? styles.inputError : ''}`}
            placeholder={field.placeholder}
            rows="3"
          />
        );

      case 'checkbox':
        return (
          <label className={styles.checkboxLabel}>
            <input
              type="checkbox"
              name={field.name}
              checked={formData[field.name] || false}
              onChange={onInputChange}
              className={styles.checkbox}
            />
            <span>Yes</span>
          </label>
        );

      default:
        return null;
    }
  };

  return (
    <div className={styles.modalOverlay} onClick={onClose}>
      <div className={styles.modal} onClick={(e) => e.stopPropagation()}>
        <div className={styles.modalHeader} style={{ background: config.gradient }}>
          <h2 className={styles.modalTitle}>{title}</h2>
          <button onClick={onClose} className={styles.modalClose}>✕</button>
        </div>
        <div className={styles.modalBody}>
          {/* Basic Fields */}
          <div className={styles.formGroup}>
            <label className={styles.formLabel}>
              Product Name <span className={styles.required}>*</span>
            </label>
            <input
              type="text"
              name="name"
              value={formData.name || ''}
              onChange={onInputChange}
              className={`${styles.formInput} ${errors.name ? styles.inputError : ''}`}
              placeholder="Enter product name"
            />
            {errors.name && <span className={styles.error}>{errors.name}</span>}
          </div>

          <div className={styles.formGroup}>
            <label className={styles.formLabel}>
              Category <span className={styles.required}>*</span>
            </label>
            <select
              name="category"
              value={formData.category || ''}
              onChange={onInputChange}
              className={`${styles.formInput} ${errors.category ? styles.inputError : ''}`}
            >
              <option value="">Select category</option>
              {config.categories.map(cat => (
                <option key={cat} value={cat}>{cat}</option>
              ))}
            </select>
            {errors.category && <span className={styles.error}>{errors.category}</span>}
          </div>

          <div className={styles.formRow}>
            <div className={styles.formGroup}>
              <label className={styles.formLabel}>
                Price (₹) <span className={styles.required}>*</span>
              </label>
              <input
                type="number"
                name="price"
                value={formData.price || ''}
                onChange={onInputChange}
                className={`${styles.formInput} ${errors.price ? styles.inputError : ''}`}
                placeholder="0"
                min="0"
                step="0.01"
              />
              {errors.price && <span className={styles.error}>{errors.price}</span>}
            </div>

            <div className={styles.formGroup}>
              <label className={styles.formLabel}>
                Stock <span className={styles.required}>*</span>
              </label>
              <input
                type="number"
                name="stock"
                value={formData.stock || ''}
                onChange={onInputChange}
                className={`${styles.formInput} ${errors.stock ? styles.inputError : ''}`}
                placeholder="0"
                min="0"
              />
              {errors.stock && <span className={styles.error}>{errors.stock}</span>}
            </div>
          </div>

          <div className={styles.formGroup}>
            <label className={styles.formLabel}>Low Stock Threshold</label>
            <input
              type="number"
              name="lowStockThreshold"
              value={formData.lowStockThreshold || 10}
              onChange={onInputChange}
              className={styles.formInput}
              min="1"
            />
          </div>

          {/* Specific Fields Based on Store Type */}
          {config.fields.specific && config.fields.specific.length > 0 && (
            <>
              <div className={styles.sectionDivider}>
                <span className={styles.sectionTitle}>Additional Details</span>
              </div>
              
              {config.fields.specific.map(field => (
                <div key={field.name} className={styles.formGroup}>
                  <label className={styles.formLabel}>
                    {field.label}
                  </label>
                  {renderField(field)}
                  {errors[field.name] && <span className={styles.error}>{errors[field.name]}</span>}
                </div>
              ))}
            </>
          )}

          <div className={styles.modalActions}>
            <button onClick={onClose} className={styles.btnCancel}>Cancel</button>
            <button onClick={onSubmit} className={styles.btnSubmit} style={{ background: config.gradient }}>
              {submitText}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}