'use client';

import { useState, useEffect } from 'react';
import { QRCodeSVG } from 'qrcode.react';
import { X, CheckCircle, Loader2, AlertCircle } from 'lucide-react';
import './QRPaymentModal.css';

export default function QRPaymentModal({ 
  isOpen, 
  onClose, 
  orderData,
  onPaymentSuccess 
}) {
  const [paymentStep, setPaymentStep] = useState('qr'); // qr, processing, success, failed
  const [countdown, setCountdown] = useState(3);
  const [transactionId, setTransactionId] = useState('');

  // Generate fake transaction ID
  useEffect(() => {
    if (isOpen) {
      const timestamp = Date.now();
      const random = Math.floor(Math.random() * 10000).toString().padStart(4, '0');
      setTransactionId(`TXN${timestamp}${random}`);
      setPaymentStep('qr');
      setCountdown(3);
    }
  }, [isOpen]);

  // Generate UPI payment string
  const generateUpiString = () => {
    const { storeName, totalAmount, orderNumber } = orderData;
    // Format: upi://pay?pa=merchant@upi&pn=MerchantName&am=amount&tn=note
    return `upi://pay?pa=noqstore@paytm&pn=${encodeURIComponent(storeName)}&am=${totalAmount}&tn=Order ${orderNumber}&cu=INR`;
  };

  // Simulate payment process
  const handlePaymentScan = () => {
    setPaymentStep('processing');
    
    // Simulate payment processing (3 seconds)
    setTimeout(() => {
      setPaymentStep('success');
      
      // Auto-close and trigger success after showing success message
      setTimeout(() => {
        onPaymentSuccess(transactionId);
        onClose();
      }, 2000);
    }, 3000);
  };

  if (!isOpen) return null;

  return (
    <div className="qr-modal-overlay" onClick={onClose}>
      <div className="qr-modal-content" onClick={(e) => e.stopPropagation()}>
        <button className="qr-modal-close" onClick={onClose}>
          <X className="w-6 h-6" />
        </button>

        {paymentStep === 'qr' && (
          <div className="qr-modal-body">
            <div className="qr-modal-header">
              <h2 className="qr-modal-title">Scan to Pay</h2>
              <p className="qr-modal-subtitle">Use any UPI app to complete payment</p>
            </div>

            <div className="qr-code-container">
              <QRCodeSVG 
                value={generateUpiString()}
                size={280}
                level="H"
                includeMargin={true}
              />
            </div>

            <div className="qr-payment-details">
              <div className="qr-payment-row">
                <span className="qr-payment-label">Store:</span>
                <span className="qr-payment-value">{orderData.storeName}</span>
              </div>
              <div className="qr-payment-row">
                <span className="qr-payment-label">Order ID:</span>
                <span className="qr-payment-value">{orderData.orderNumber}</span>
              </div>
              <div className="qr-payment-row total">
                <span className="qr-payment-label">Amount:</span>
                <span className="qr-payment-value">₹{orderData.totalAmount.toFixed(2)}</span>
              </div>
            </div>

            <div className="qr-supported-apps">
              <p className="qr-supported-label">Supported Apps:</p>
              <div className="qr-apps-grid">
                <span className="qr-app-badge">Google Pay</span>
                <span className="qr-app-badge">PhonePe</span>
                <span className="qr-app-badge">Paytm</span>
                <span className="qr-app-badge">BHIM</span>
              </div>
            </div>

            <button 
              className="qr-simulate-btn"
              onClick={handlePaymentScan}
            >
              🧪 Simulate Payment (Demo Mode)
            </button>
          </div>
        )}

        {paymentStep === 'processing' && (
          <div className="qr-modal-body">
            <div className="qr-processing-animation">
              <Loader2 className="qr-spinner" />
            </div>
            <h2 className="qr-modal-title">Processing Payment...</h2>
            <p className="qr-modal-subtitle">Please wait while we verify your payment</p>
            <div className="qr-transaction-id">
              Transaction ID: {transactionId}
            </div>
          </div>
        )}

        {paymentStep === 'success' && (
          <div className="qr-modal-body">
            <div className="qr-success-animation">
              <CheckCircle className="qr-success-icon" />
            </div>
            <h2 className="qr-modal-title success">Payment Successful!</h2>
            <p className="qr-modal-subtitle">Your order has been confirmed</p>
            <div className="qr-success-details">
              <div className="qr-success-row">
                <span>Transaction ID:</span>
                <span className="qr-txn-id">{transactionId}</span>
              </div>
              <div className="qr-success-row">
                <span>Amount Paid:</span>
                <span className="qr-amount">₹{orderData.totalAmount.toFixed(2)}</span>
              </div>
            </div>
            <p className="qr-redirect-text">Redirecting to your token...</p>
          </div>
        )}

        {paymentStep === 'failed' && (
          <div className="qr-modal-body">
            <div className="qr-failed-animation">
              <AlertCircle className="qr-failed-icon" />
            </div>
            <h2 className="qr-modal-title failed">Payment Failed</h2>
            <p className="qr-modal-subtitle">Please try again</p>
            <button 
              className="qr-retry-btn"
              onClick={() => setPaymentStep('qr')}
            >
              Retry Payment
            </button>
          </div>
        )}
      </div>
    </div>
  );
}