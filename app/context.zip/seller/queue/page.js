// File: app/seller/queue/page.js
// This is the page route for Queue Management

import QueueManagement from '../../components/QueueManagement';

export const metadata = {
  title: 'Queue Management | NoQ Seller Dashboard',
  description: 'Manage your live queue, serve customers, and track wait times in real-time',
};

export default function QueuePage() {
  return <QueueManagement />;
}