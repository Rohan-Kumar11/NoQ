import SellerRegistration from '@/app/components/SellerRegistration';

export const metadata = {
  title: 'Seller Registration | NoQ',
  description: 'Register your business with NoQ virtual queue management system',
};

export default function SellerRegisterPage() {
  return <SellerRegistration />;
}