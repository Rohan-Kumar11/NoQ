import SellerDashboard from '@/app/components/SellerDashboard';

export const metadata = {
  title: 'Dashboard | NoQ Seller',
  description: 'Real-time seller dashboard for NoQ queue management system',
};

export default function SellerDashboardPage() {
  return <SellerDashboard />;
}