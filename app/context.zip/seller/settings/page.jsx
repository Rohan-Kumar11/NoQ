'use client';

import { useState, useEffect } from 'react';
import { motion } from 'framer-motion';
import { useRouter } from 'next/navigation';
import { getStoreDetails, updateStoreProfile } from '@/lib/auth';
import Sidebar from '../../components/Sidebar';
import styles from './Sellersettings.module.css';

export default function SellerSettings() {
  const router = useRouter();
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [activeTab, setActiveTab] = useState('basic');
  const [message, setMessage] = useState({ type: '', text: '' });
  const [detectingLocation, setDetectingLocation] = useState(false);

  const [formData, setFormData] = useState({
    // Basic Information
    store_name: '',
    store_type: '',
    description: '',
    logo_url: '',
    
    // Contact Information
    phone: '',
    email: '',
    website: '',
    
    // Location
    address: '',
    city: '',
    state: '',
    pincode: '',
    landmark: '',
    latitude: '',
    longitude: '',
    
    // Operating Hours
    working_days: [],
    opening_time: '',
    closing_time: '',
    operating_hours: {
      monday: { open: '09:00', close: '21:00', closed: false },
      tuesday: { open: '09:00', close: '21:00', closed: false },
      wednesday: { open: '09:00', close: '21:00', closed: false },
      thursday: { open: '09:00', close: '21:00', closed: false },
      friday: { open: '09:00', close: '21:00', closed: false },
      saturday: { open: '09:00', close: '21:00', closed: false },
      sunday: { open: '10:00', close: '21:00', closed: false }
    },
    
    // Queue Settings
    max_tokens_per_hour: 20,
    avg_service_time: 15,
    queue_capacity: 50,
    notification_timing: 5,
    auto_call_next: false,
    estimated_service_time: 15,
    
    // Status
    is_active: true,
    is_open: false
  });

  // Load store data
  useEffect(() => {
    async function loadStoreData() {
      try {
        setLoading(true);
        const result = await getStoreDetails();
        
        if (result.success && result.data) {
          // Ensure all fields have values (fix uncontrolled input error)
          const safeData = {
            store_name: result.data.store_name || '',
            store_type: result.data.store_type || '',
            description: result.data.description || '',
            logo_url: result.data.logo_url || '',
            phone: result.data.phone || '',
            email: result.data.email || '',
            website: result.data.website || '',
            address: result.data.address || '',
            city: result.data.city || '',
            state: result.data.state || '',
            pincode: result.data.pincode || '',
            landmark: result.data.landmark || '',
            latitude: result.data.latitude || '',
            longitude: result.data.longitude || '',
            working_days: result.data.working_days || [],
            opening_time: result.data.opening_time || '',
            closing_time: result.data.closing_time || '',
            operating_hours: result.data.operating_hours || {
              monday: { open: '09:00', close: '21:00', closed: false },
              tuesday: { open: '09:00', close: '21:00', closed: false },
              wednesday: { open: '09:00', close: '21:00', closed: false },
              thursday: { open: '09:00', close: '21:00', closed: false },
              friday: { open: '09:00', close: '21:00', closed: false },
              saturday: { open: '09:00', close: '21:00', closed: false },
              sunday: { open: '10:00', close: '21:00', closed: false }
            },
            max_tokens_per_hour: result.data.max_tokens_per_hour || 20,
            avg_service_time: result.data.avg_service_time || 15,
            queue_capacity: result.data.queue_capacity || 50,
            notification_timing: result.data.notification_timing || 5,
            auto_call_next: result.data.auto_call_next || false,
            estimated_service_time: result.data.estimated_service_time || 15,
            is_active: result.data.is_active !== undefined ? result.data.is_active : true,
            is_open: result.data.is_open || false
          };
          setFormData(safeData);
        } else {
          setMessage({ type: 'error', text: 'Failed to load store details' });
        }
      } catch (error) {
        console.error('Load error:', error);
        setMessage({ type: 'error', text: 'An error occurred' });
      } finally {
        setLoading(false);
      }
    }

    loadStoreData();
  }, []);

  const handleInputChange = (e) => {
    const { name, value, type, checked } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: type === 'checkbox' ? checked : value
    }));
  };

  const handleWorkingDaysChange = (day) => {
    setFormData(prev => ({
      ...prev,
      working_days: prev.working_days.includes(day)
        ? prev.working_days.filter(d => d !== day)
        : [...prev.working_days, day]
    }));
  };

  const handleOperatingHoursChange = (day, field, value) => {
    setFormData(prev => ({
      ...prev,
      operating_hours: {
        ...prev.operating_hours,
        [day]: {
          ...prev.operating_hours[day],
          [field]: value
        }
      }
    }));
  };

  // Auto-detect location function
  const handleAutoDetectLocation = async () => {
    if (!navigator.geolocation) {
      setMessage({ type: 'error', text: 'Geolocation is not supported by your browser' });
      return;
    }

    setDetectingLocation(true);
    setMessage({ type: 'info', text: 'Detecting your location...' });

    navigator.geolocation.getCurrentPosition(
      async (position) => {
        const { latitude, longitude } = position.coords;
        
        // Update coordinates
        setFormData(prev => ({
          ...prev,
          latitude: latitude.toFixed(6),
          longitude: longitude.toFixed(6)
        }));

        // Try to get address from coordinates using reverse geocoding
        try {
          const response = await fetch(
            `https://nominatim.openstreetmap.org/reverse?format=json&lat=${latitude}&lon=${longitude}`
          );
          const data = await response.json();
          
          if (data.address) {
            setFormData(prev => ({
              ...prev,
              latitude: latitude.toFixed(6),
              longitude: longitude.toFixed(6),
              city: data.address.city || data.address.town || data.address.village || prev.city,
              state: data.address.state || prev.state,
              pincode: data.address.postcode || prev.pincode,
              address: data.display_name || prev.address
            }));
            setMessage({ type: 'success', text: 'Location detected successfully!' });
          }
        } catch (error) {
          console.error('Geocoding error:', error);
          setMessage({ type: 'success', text: 'Coordinates detected! Please fill in address details.' });
        }
        
        setDetectingLocation(false);
        setTimeout(() => setMessage({ type: '', text: '' }), 3000);
      },
      (error) => {
        setDetectingLocation(false);
        let errorMessage = 'Failed to detect location';
        
        switch(error.code) {
          case error.PERMISSION_DENIED:
            errorMessage = 'Location permission denied. Please enable location access.';
            break;
          case error.POSITION_UNAVAILABLE:
            errorMessage = 'Location information unavailable.';
            break;
          case error.TIMEOUT:
            errorMessage = 'Location request timed out.';
            break;
        }
        
        setMessage({ type: 'error', text: errorMessage });
        setTimeout(() => setMessage({ type: '', text: '' }), 3000);
      },
      {
        enableHighAccuracy: true,
        timeout: 10000,
        maximumAge: 0
      }
    );
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setSaving(true);
    setMessage({ type: '', text: '' });

    try {
      const result = await updateStoreProfile(formData);
      
      if (result.success) {
        setMessage({ type: 'success', text: 'Settings updated successfully!' });
        setTimeout(() => setMessage({ type: '', text: '' }), 3000);
      } else {
        setMessage({ type: 'error', text: result.error || 'Failed to update settings' });
      }
    } catch (error) {
      console.error('Update error:', error);
      setMessage({ type: 'error', text: 'An error occurred while saving' });
    } finally {
      setSaving(false);
    }
  };

  const tabs = [
    { id: 'basic', label: 'Basic Info', icon: '🏪' },
    { id: 'location', label: 'Location', icon: '📍' },
    { id: 'hours', label: 'Operating Hours', icon: '🕐' },
    { id: 'queue', label: 'Queue Settings', icon: '🎫' },
    { id: 'advanced', label: 'Advanced', icon: '⚙️' }
  ];

  if (loading) {
    return (
      <div className={styles.dashboard}>
        <Sidebar />
        <main className={styles.mainContent}>
          <div className={styles.loadingContainer}>
            <div className={styles.loader}></div>
            <p>Loading settings...</p>
          </div>
        </main>
      </div>
    );
  }

  return (
    <div className={styles.dashboard}>
      <Sidebar />
      
      <main className={styles.mainContent}>
        {/* Header */}
        <motion.div
          className={styles.header}
          initial={{ opacity: 0, y: -20 }}
          animate={{ opacity: 1, y: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className={styles.headerLeft}>
            <button 
              className={styles.backButton}
              onClick={() => router.push('/seller/dashboard')}
            >
              ← Back
            </button>
            <div>
              <h1 className={styles.pageTitle}>Store Settings</h1>
              <p className={styles.pageSubtitle}>Manage your store information and preferences</p>
            </div>
          </div>
          <button
            className={styles.saveButton}
            onClick={handleSubmit}
            disabled={saving}
          >
            {saving ? 'Saving...' : 'Save Changes'}
          </button>
        </motion.div>

        {/* Message Alert */}
        {message.text && (
          <motion.div
            className={`${styles.alert} ${styles[message.type]}`}
            initial={{ opacity: 0, y: -10 }}
            animate={{ opacity: 1, y: 0 }}
          >
            {message.type === 'success' ? '✓' : message.type === 'error' ? '⚠' : 'ℹ'} {message.text}
          </motion.div>
        )}

        <div className={styles.settingsContainer}>
          {/* Tabs Navigation */}
          <motion.div
            className={styles.tabsNav}
            initial={{ opacity: 0, x: -20 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.5, delay: 0.2 }}
          >
            {tabs.map((tab, index) => (
              <motion.button
                key={tab.id}
                className={`${styles.tab} ${activeTab === tab.id ? styles.activeTab : ''}`}
                onClick={() => setActiveTab(tab.id)}
                initial={{ opacity: 0, x: -20 }}
                animate={{ opacity: 1, x: 0 }}
                transition={{ duration: 0.3, delay: index * 0.1 }}
                whileHover={{ x: 5 }}
              >
                <span className={styles.tabIcon}>{tab.icon}</span>
                <span className={styles.tabLabel}>{tab.label}</span>
              </motion.button>
            ))}
          </motion.div>

          {/* Tab Content */}
          <motion.div
            className={styles.tabContent}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.5, delay: 0.3 }}
          >
            <form onSubmit={handleSubmit}>
              {activeTab === 'basic' && (
                <BasicInfoTab formData={formData} handleInputChange={handleInputChange} />
              )}
              
              {activeTab === 'location' && (
                <LocationTab 
                  formData={formData} 
                  handleInputChange={handleInputChange}
                  handleAutoDetectLocation={handleAutoDetectLocation}
                  detectingLocation={detectingLocation}
                />
              )}
              
              {activeTab === 'hours' && (
                <OperatingHoursTab
                  formData={formData}
                  handleInputChange={handleInputChange}
                  handleWorkingDaysChange={handleWorkingDaysChange}
                  handleOperatingHoursChange={handleOperatingHoursChange}
                />
              )}
              
              {activeTab === 'queue' && (
                <QueueSettingsTab formData={formData} handleInputChange={handleInputChange} />
              )}
              
              {activeTab === 'advanced' && (
                <AdvancedTab formData={formData} handleInputChange={handleInputChange} />
              )}
            </form>
          </motion.div>
        </div>
      </main>
    </div>
  );
}

// Basic Info Tab Component
function BasicInfoTab({ formData, handleInputChange }) {
  return (
    <motion.div
      className={styles.section}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
    >
      <h2 className={styles.sectionTitle}>Basic Information</h2>
      
      <div className={styles.formGrid}>
        <div className={styles.formGroup}>
          <label className={styles.label}>Store Name *</label>
          <input
            type="text"
            name="store_name"
            value={formData.store_name || ''}
            onChange={handleInputChange}
            className={styles.input}
            placeholder="Enter store name"
            required
          />
        </div>

        <div className={styles.formGroup}>
          <label className={styles.label}>Store Type *</label>
          <select
            name="store_type"
            value={formData.store_type || ''}
            onChange={handleInputChange}
            className={styles.select}
            required
          >
            <option value="">Select type</option>
            <option value="retail">Retail</option>
            <option value="healthcare">Healthcare</option>
            <option value="food-beverage">Food & Beverage</option>
            <option value="government">Government</option>
            <option value="banking">Banking</option>
            <option value="hospitality">Hospitality</option>
            <option value="other">Other</option>
          </select>
        </div>

        <div className={styles.formGroup}>
          <label className={styles.label}>Phone</label>
          <input
            type="tel"
            name="phone"
            value={formData.phone || ''}
            onChange={handleInputChange}
            className={styles.input}
            placeholder="+91 XXXXX XXXXX"
          />
        </div>

        <div className={styles.formGroup}>
          <label className={styles.label}>Email</label>
          <input
            type="email"
            name="email"
            value={formData.email || ''}
            onChange={handleInputChange}
            className={styles.input}
            placeholder="store@example.com"
          />
        </div>

        <div className={styles.formGroup}>
          <label className={styles.label}>Website</label>
          <input
            type="url"
            name="website"
            value={formData.website || ''}
            onChange={handleInputChange}
            className={styles.input}
            placeholder="https://yourwebsite.com"
          />
        </div>

        <div className={styles.formGroup}>
          <label className={styles.label}>Logo URL</label>
          <input
            type="url"
            name="logo_url"
            value={formData.logo_url || ''}
            onChange={handleInputChange}
            className={styles.input}
            placeholder="https://example.com/logo.png"
          />
        </div>

        <div className={`${styles.formGroup} ${styles.fullWidth}`}>
          <label className={styles.label}>Description</label>
          <textarea
            name="description"
            value={formData.description || ''}
            onChange={handleInputChange}
            className={styles.textarea}
            placeholder="Tell customers about your store..."
            rows={4}
          />
        </div>
      </div>
    </motion.div>
  );
}

// Location Tab Component
function LocationTab({ formData, handleInputChange, handleAutoDetectLocation, detectingLocation }) {
  return (
    <motion.div
      className={styles.section}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
    >
      <div className={styles.sectionHeader}>
        <h2 className={styles.sectionTitle}>Location Details</h2>
        <button
          type="button"
          className={styles.detectLocationBtn}
          onClick={handleAutoDetectLocation}
          disabled={detectingLocation}
        >
          {detectingLocation ? (
            <>
              <span className={styles.spinner}></span>
              Detecting...
            </>
          ) : (
            <>
              <span className={styles.locationIcon}>📍</span>
              Auto-Detect Location
            </>
          )}
        </button>
      </div>
      
      <div className={styles.formGrid}>
        <div className={`${styles.formGroup} ${styles.fullWidth}`}>
          <label className={styles.label}>Address *</label>
          <textarea
            name="address"
            value={formData.address || ''}
            onChange={handleInputChange}
            className={styles.textarea}
            placeholder="Enter complete address"
            rows={3}
            required
          />
        </div>

        <div className={styles.formGroup}>
          <label className={styles.label}>City *</label>
          <input
            type="text"
            name="city"
            value={formData.city || ''}
            onChange={handleInputChange}
            className={styles.input}
            placeholder="City"
            required
          />
        </div>

        <div className={styles.formGroup}>
          <label className={styles.label}>State *</label>
          <input
            type="text"
            name="state"
            value={formData.state || ''}
            onChange={handleInputChange}
            className={styles.input}
            placeholder="State"
            required
          />
        </div>

        <div className={styles.formGroup}>
          <label className={styles.label}>Pincode *</label>
          <input
            type="text"
            name="pincode"
            value={formData.pincode || ''}
            onChange={handleInputChange}
            className={styles.input}
            placeholder="110001"
            required
          />
        </div>

        <div className={styles.formGroup}>
          <label className={styles.label}>Landmark</label>
          <input
            type="text"
            name="landmark"
            value={formData.landmark || ''}
            onChange={handleInputChange}
            className={styles.input}
            placeholder="Near..."
          />
        </div>

        <div className={styles.formGroup}>
          <label className={styles.label}>
            Latitude
            {formData.latitude && <span className={styles.coordBadge}>Detected</span>}
          </label>
          <input
            type="text"
            name="latitude"
            value={formData.latitude || ''}
            onChange={handleInputChange}
            className={styles.input}
            placeholder="28.6139"
            readOnly={detectingLocation}
          />
        </div>

        <div className={styles.formGroup}>
          <label className={styles.label}>
            Longitude
            {formData.longitude && <span className={styles.coordBadge}>Detected</span>}
          </label>
          <input
            type="text"
            name="longitude"
            value={formData.longitude || ''}
            onChange={handleInputChange}
            className={styles.input}
            placeholder="77.2090"
            readOnly={detectingLocation}
          />
        </div>
      </div>

      {formData.latitude && formData.longitude && (
        <div className={styles.mapPreview}>
          <p className={styles.mapText}>
            📍 Location: {formData.latitude}, {formData.longitude}
          </p>
        </div>
      )}
    </motion.div>
  );
}

// Time conversion utilities
function convertTo12Hour(time24) {
  if (!time24) return '';
  const [hours, minutes] = time24.split(':');
  const hour = parseInt(hours, 10);
  const period = hour >= 12 ? 'PM' : 'AM';
  const hour12 = hour === 0 ? 12 : hour > 12 ? hour - 12 : hour;
  return `${hour12}:${minutes} ${period}`;
}

function convertTo24Hour(time12) {
  if (!time12) return '';
  const [time, period] = time12.split(' ');
  const [hours, minutes] = time.split(':');
  let hour = parseInt(hours, 10);
  
  if (period === 'PM' && hour !== 12) {
    hour += 12;
  } else if (period === 'AM' && hour === 12) {
    hour = 0;
  }
  
  return `${hour.toString().padStart(2, '0')}:${minutes}`;
}

// Operating Hours Tab Component with AM/PM support
function OperatingHoursTab({ formData, handleInputChange, handleWorkingDaysChange, handleOperatingHoursChange }) {
  const days = ['Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat', 'Sun'];
  const dayMap = {
    'Mon': 'monday',
    'Tue': 'tuesday',
    'Wed': 'wednesday',
    'Thu': 'thursday',
    'Fri': 'friday',
    'Sat': 'saturday',
    'Sun': 'sunday'
  };

  return (
    <motion.div
      className={styles.section}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
    >
      <h2 className={styles.sectionTitle}>Operating Hours</h2>
      
      <div className={styles.formGrid}>
        <div className={styles.formGroup}>
          <label className={styles.label}>General Opening Time</label>
          <div className={styles.timeInputWrapper}>
            <input
              type="time"
              name="opening_time"
              value={formData.opening_time || ''}
              onChange={handleInputChange}
              className={styles.input}
            />
            <span className={styles.timeDisplay}>
              {formData.opening_time && convertTo12Hour(formData.opening_time)}
            </span>
          </div>
        </div>

        <div className={styles.formGroup}>
          <label className={styles.label}>General Closing Time</label>
          <div className={styles.timeInputWrapper}>
            <input
              type="time"
              name="closing_time"
              value={formData.closing_time || ''}
              onChange={handleInputChange}
              className={styles.input}
            />
            <span className={styles.timeDisplay}>
              {formData.closing_time && convertTo12Hour(formData.closing_time)}
            </span>
          </div>
        </div>
      </div>

      <div className={styles.workingDaysSection}>
        <label className={styles.label}>Working Days</label>
        <div className={styles.dayButtons}>
          {days.map(day => (
            <button
              key={day}
              type="button"
              className={`${styles.dayButton} ${
                formData.working_days?.includes(day) ? styles.activeDayButton : ''
              }`}
              onClick={() => handleWorkingDaysChange(day)}
            >
              {day}
            </button>
          ))}
        </div>
      </div>

      <div className={styles.detailedHours}>
        <h3 className={styles.subsectionTitle}>Detailed Hours by Day</h3>
        {Object.keys(dayMap).map(day => {
          const dayData = formData.operating_hours[dayMap[day]] || { open: '09:00', close: '21:00', closed: false };
          return (
            <div key={day} className={styles.dayHourRow}>
              <div className={styles.dayHourDay}>
                <input
                  type="checkbox"
                  id={`closed-${day}`}
                  checked={!dayData.closed}
                  onChange={(e) => handleOperatingHoursChange(dayMap[day], 'closed', !e.target.checked)}
                  className={styles.checkbox}
                />
                <label htmlFor={`closed-${day}`}>{day}</label>
              </div>
              <div className={styles.dayHourInputs}>
                <div className={styles.timeInputGroup}>
                  <input
                    type="time"
                    value={dayData.open || '09:00'}
                    onChange={(e) => handleOperatingHoursChange(dayMap[day], 'open', e.target.value)}
                    className={styles.timeInput}
                    disabled={dayData.closed}
                  />
                  <span className={styles.timeLabel}>
                    {!dayData.closed && convertTo12Hour(dayData.open || '09:00')}
                  </span>
                </div>
                <span className={styles.timeSeparator}>to</span>
                <div className={styles.timeInputGroup}>
                  <input
                    type="time"
                    value={dayData.close || '21:00'}
                    onChange={(e) => handleOperatingHoursChange(dayMap[day], 'close', e.target.value)}
                    className={styles.timeInput}
                    disabled={dayData.closed}
                  />
                  <span className={styles.timeLabel}>
                    {!dayData.closed && convertTo12Hour(dayData.close || '21:00')}
                  </span>
                </div>
              </div>
            </div>
          );
        })}
      </div>
    </motion.div>
  );
}

// Queue Settings Tab Component
function QueueSettingsTab({ formData, handleInputChange }) {
  return (
    <motion.div
      className={styles.section}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
    >
      <h2 className={styles.sectionTitle}>Queue Management</h2>
      
      <div className={styles.formGrid}>
        <div className={styles.formGroup}>
          <label className={styles.label}>Max Tokens Per Hour</label>
          <input
            type="number"
            name="max_tokens_per_hour"
            value={formData.max_tokens_per_hour || 20}
            onChange={handleInputChange}
            className={styles.input}
            min="1"
            max="100"
          />
          <p className={styles.helpText}>Maximum number of tokens that can be issued per hour</p>
        </div>

        <div className={styles.formGroup}>
          <label className={styles.label}>Queue Capacity</label>
          <input
            type="number"
            name="queue_capacity"
            value={formData.queue_capacity || 50}
            onChange={handleInputChange}
            className={styles.input}
            min="1"
            max="500"
          />
          <p className={styles.helpText}>Total queue capacity</p>
        </div>

        <div className={styles.formGroup}>
          <label className={styles.label}>Avg Service Time (minutes)</label>
          <input
            type="number"
            name="avg_service_time"
            value={formData.avg_service_time || 15}
            onChange={handleInputChange}
            className={styles.input}
            min="1"
            max="120"
          />
          <p className={styles.helpText}>Average time to serve one customer</p>
        </div>

        <div className={styles.formGroup}>
          <label className={styles.label}>Estimated Service Time (minutes)</label>
          <input
            type="number"
            name="estimated_service_time"
            value={formData.estimated_service_time || 15}
            onChange={handleInputChange}
            className={styles.input}
            min="1"
            max="120"
          />
          <p className={styles.helpText}>Estimated time shown to customers</p>
        </div>

        <div className={styles.formGroup}>
          <label className={styles.label}>Notification Timing (minutes)</label>
          <input
            type="number"
            name="notification_timing"
            value={formData.notification_timing || 5}
            onChange={handleInputChange}
            className={styles.input}
            min="1"
            max="30"
          />
          <p className={styles.helpText}>Send notification X minutes before turn</p>
        </div>

        <div className={`${styles.formGroup} ${styles.fullWidth}`}>
          <label className={styles.switchLabel}>
            <input
              type="checkbox"
              name="auto_call_next"
              checked={formData.auto_call_next || false}
              onChange={handleInputChange}
              className={styles.switchInput}
            />
            <span className={styles.switch}></span>
            <span>Auto Call Next Customer</span>
          </label>
          <p className={styles.helpText}>Automatically notify next customer when previous is served</p>
        </div>
      </div>
    </motion.div>
  );
}

// Advanced Tab Component
function AdvancedTab({ formData, handleInputChange }) {
  return (
    <motion.div
      className={styles.section}
      initial={{ opacity: 0 }}
      animate={{ opacity: 1 }}
    >
      <h2 className={styles.sectionTitle}>Advanced Settings</h2>
      
      <div className={styles.formGrid}>
        <div className={`${styles.formGroup} ${styles.fullWidth}`}>
          <label className={styles.switchLabel}>
            <input
              type="checkbox"
              name="is_active"
              checked={formData.is_active || false}
              onChange={handleInputChange}
              className={styles.switchInput}
            />
            <span className={styles.switch}></span>
            <span>Store Active</span>
          </label>
          <p className={styles.helpText}>Make your store visible to customers</p>
        </div>

        <div className={`${styles.formGroup} ${styles.fullWidth}`}>
          <label className={styles.switchLabel}>
            <input
              type="checkbox"
              name="is_open"
              checked={formData.is_open || false}
              onChange={handleInputChange}
              className={styles.switchInput}
            />
            <span className={styles.switch}></span>
            <span>Store Currently Open</span>
          </label>
          <p className={styles.helpText}>Customers can join queue when store is open</p>
        </div>

        <div className={`${styles.formGroup} ${styles.fullWidth}`}>
          <div className={styles.dangerZone}>
            <h3>Danger Zone</h3>
            <p>Destructive actions that can affect your store operations</p>
            <button type="button" className={styles.dangerButton}>
              Pause All Queue Operations
            </button>
            <button type="button" className={styles.dangerButton}>
              Clear All Waiting Customers
            </button>
          </div>
        </div>
      </div>
    </motion.div>
  );
}