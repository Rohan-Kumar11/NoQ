import StoreProfile from '../../components/StoreProfile';

export default function ProfilePage() {
  return <StoreProfile />;
}