'use client'

import { useEffect, useRef } from 'react'
import { motion, useScroll, useTransform, useInView } from 'framer-motion'
import CountUp from 'react-countup'
import { useInView as useInViewHook } from 'react-intersection-observer'
import styles from './Hero.module.css'

export default function Hero() {
  const containerRef = useRef(null)
  const { scrollYProgress } = useScroll({
    target: containerRef,
    offset: ["start start", "end start"]
  })

  const y = useTransform(scrollYProgress, [0, 1], ["0%", "50%"])
  const opacity = useTransform(scrollYProgress, [0, 1], [1, 0])
  const scale = useTransform(scrollYProgress, [0, 1], [1, 0.8])

  const { ref: statsRef, inView: statsInView } = useInViewHook({
    threshold: 0.3,
    triggerOnce: true
  })

  const floatingAnimation = {
    y: [0, -20, 0],
    transition: {
      duration: 3,
      repeat: Infinity,
      ease: "easeInOut"
    }
  }

  return (
    <section className={styles.hero} ref={containerRef}>
      <motion.div 
        className={styles.heroContent}
        style={{ y, opacity }}
      >
        <div className={styles.heroText}>
          <motion.span
            className={styles.heroLabel}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.2 }}
          >
            Revolutionizing Customer Experience
          </motion.span>

          <motion.h1
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 0.4 }}
          >
            No Wait,<br />Only{' '}
            <span className={styles.gradientText}>Satisfaction</span>
          </motion.h1>

          <motion.p
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.6 }}
          >
            Transform customer experience with AI-driven queue management. 
            Eliminate physical lines, reduce wait times, and create seamless 
            service experiences that customers love.
          </motion.p>

          <motion.div
            className={styles.heroCtas}
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.6, delay: 0.8 }}
          >
            <motion.a
              href="/get-started"
              className={styles.primaryCta}
              whileHover={{ scale: 1.05, y: -3 }}
              whileTap={{ scale: 0.95 }}
            >
              Request Demo
            </motion.a>
            <motion.a
              href="#learn-more"
              className={styles.secondaryCta}
              whileHover={{ x: 10 }}
            >
              Learn More <span>→</span>
            </motion.a>
          </motion.div>

          <motion.div
            ref={statsRef}
            className={styles.heroStats}
            initial={{ opacity: 0, y: 30 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.8, delay: 1 }}
          >
            {[
              { number: 67, label: 'Reduced Crowding', suffix: '%' },
              { number: 78, label: 'Customer Preference', suffix: '%' },
              { number: 89, label: 'Retention Rate', suffix: '%' }
            ].map((stat, i) => (
              <motion.div
                key={i}
                className={styles.statItem}
                initial={{ opacity: 0, scale: 0.5 }}
                animate={statsInView ? { opacity: 1, scale: 1 } : {}}
                transition={{ duration: 0.5, delay: i * 0.1 }}
              >
                <span className={styles.statNumber}>
                  {statsInView && (
                    <CountUp
                      end={stat.number}
                      duration={2.5}
                      suffix={stat.suffix}
                    />
                  )}
                </span>
                <span className={styles.statLabel}>{stat.label}</span>
              </motion.div>
            ))}
          </motion.div>
        </div>

        <motion.div
          className={styles.heroVisual}
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 1, delay: 0.5 }}
          style={{ scale }}
        >
          <AnimatedQueueVisual />
        </motion.div>
      </motion.div>

      {/* Animated Background Elements */}
      <motion.div
        className={styles.floatingCircle1}
        animate={floatingAnimation}
      />
      <motion.div
        className={styles.floatingCircle2}
        animate={{
          y: [0, 30, 0],
          transition: {
            duration: 4,
            repeat: Infinity,
            ease: "easeInOut"
          }
        }}
      />
    </section>
  )
}

function AnimatedQueueVisual() {
  const queueItems = [
    { name: 'Sarah M.', position: 'Next in line', time: '2 min', color: 'linear-gradient(135deg, #4A90E2, #5BA3F5)' },
    { name: 'John D.', position: 'Position #2', time: '5 min', color: 'linear-gradient(135deg, #8B5CF6, #A78BFA)' },
    { name: 'Emma R.', position: 'Position #3', time: '8 min', color: 'linear-gradient(135deg, #EC4899, #F472B6)' }
  ]

  return (
    <div className={styles.visualCard}>
      <motion.div
        className={styles.cardGlow}
        animate={{
          opacity: [0.3, 0.6, 0.3],
          scale: [1, 1.05, 1],
        }}
        transition={{
          duration: 3,
          repeat: Infinity,
          ease: "easeInOut"
        }}
      />
      <div className={styles.queueVisualization}>
        {queueItems.map((item, i) => (
          <motion.div
            key={i}
            className={styles.queueItem}
            initial={{ opacity: 0, x: -50 }}
            animate={{ opacity: 1, x: 0 }}
            transition={{ duration: 0.6, delay: 1 + i * 0.2 }}
            whileHover={{ 
              x: 10, 
              transition: { duration: 0.2 } 
            }}
          >
            <motion.div
              className={styles.queueAvatar}
              style={{ background: item.color }}
              animate={{
                scale: [1, 1.1, 1],
              }}
              transition={{
                duration: 2,
                delay: i * 0.3,
                repeat: Infinity,
                repeatType: "reverse"
              }}
            />
            <div className={styles.queueInfo}>
              <h4>{item.name}</h4>
              <p>{item.position} • Wait time: {item.time}</p>
            </div>
            <motion.div
              className={styles.pulseIndicator}
              animate={{
                scale: [1, 1.3, 1],
                opacity: [0.5, 1, 0.5],
              }}
              transition={{
                duration: 2,
                repeat: Infinity,
                delay: i * 0.4
              }}
            />
          </motion.div>
        ))}
      </div>
    </div>
  )
}