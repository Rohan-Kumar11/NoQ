'use client';

import { usePathname, useRouter } from 'next/navigation';
import { useEffect, useState } from 'react';
import Link from 'next/link';
import { supabase } from '@/lib/supabase/client';
import { signOut } from '@/lib/auth';
import toast from 'react-hot-toast';
import styles from './Sidebar.module.css';

export default function Sidebar() {
  const pathname = usePathname();
  const router = useRouter();
  
  const [userData, setUserData] = useState({
    fullName: '',
    storeName: '',
    userEmail: '',
    initials: '',
    loading: true
  });

  const [isLoggingOut, setIsLoggingOut] = useState(false);

  const navItems = [
    { href: '/seller/dashboard', icon: '📊', label: 'Dashboard' },
    { href: '/seller/products', icon: '📦', label: 'Products' },
    { href: '/seller/queue', icon: '🎫', label: 'Live Queue' },
    { href: '/seller/orders', icon: '🧾', label: 'Orders' },
    { href: '/seller/payments', icon: '💳', label: 'Payments' },
    { href: '/seller/notifications', icon: '🔔', label: 'Notifications' },
    { href: '/seller/analytics', icon: '📈', label: 'Analytics' },
    { href: '/seller/settings', icon: '⚙️', label: 'Settings' },
  ];

  // Fetch user data on component mount
  useEffect(() => {
    async function fetchUserData() {
      try {
        // Get authenticated user
        const { data: { user }, error: userError } = await supabase.auth.getUser();
        
        if (userError || !user) {
          console.error('User not authenticated:', userError);
          setUserData(prev => ({ ...prev, loading: false }));
          return;
        }

        // Fetch user profile (full_name)
        const { data: profile, error: profileError } = await supabase
          .from('profiles')
          .select('full_name, user_type')
          .eq('id', user.id)
          .single();

        if (profileError) {
          console.error('Error fetching profile:', profileError);
        }

        // Fetch store details (store_name)
        const { data: store, error: storeError } = await supabase
          .from('stores')
          .select('store_name')
          .eq('owner_id', user.id)
          .single();

        if (storeError) {
          console.error('Error fetching store:', storeError);
        }

        // Generate initials from full name
        const fullName = profile?.full_name || 'User';
        const nameParts = fullName.trim().split(' ');
        let initials = '';
        
        if (nameParts.length >= 2) {
          // First and last name initials
          initials = nameParts[0][0] + nameParts[nameParts.length - 1][0];
        } else if (nameParts.length === 1) {
          // Single name - use first two letters
          initials = nameParts[0].substring(0, 2);
        }

        setUserData({
          fullName: fullName,
          storeName: store?.store_name || 'Store',
          userEmail: user.email || '',
          initials: initials.toUpperCase(),
          loading: false
        });

      } catch (error) {
        console.error('Error in fetchUserData:', error);
        setUserData(prev => ({ ...prev, loading: false }));
      }
    }

    fetchUserData();
  }, []);

  // Handle logout
  const handleLogout = async () => {
    if (isLoggingOut) return;

    const confirmLogout = window.confirm('Are you sure you want to logout?');
    if (!confirmLogout) return;

    setIsLoggingOut(true);

    try {
      const result = await signOut();
      
      if (result.success) {
        toast.success('Logged out successfully');
        // Redirect to home page
        router.push('/');
      } else {
        toast.error(result.error || 'Failed to logout');
        setIsLoggingOut(false);
      }
    } catch (error) {
      console.error('Logout error:', error);
      toast.error('An error occurred during logout');
      setIsLoggingOut(false);
    }
  };

  return (
    <aside className={styles.sidebar}>
      <div className={styles.sidebarHeader}>
        <Link href="/seller/dashboard" className={styles.logo}>
          <span className={styles.logoIcon}>🎫</span>
          <span className={styles.logoText}>NoQ</span>
        </Link>
      </div>

      <nav className={styles.navigation}>
        {navItems.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className={`${styles.navItem} ${pathname === item.href ? styles.navItemActive : ''}`}
          >
            <span className={styles.navIcon}>{item.icon}</span>
            <span className={styles.navText}>{item.label}</span>
          </Link>
        ))}
      </nav>

      <div className={styles.sidebarFooter}>
        {/* User Profile Section */}
        <div className={styles.userProfile}>
          <div className={styles.userAvatar}>
            {userData.loading ? '...' : userData.initials}
          </div>
          <div className={styles.userInfo}>
            <div className={styles.userName}>
              {userData.loading ? 'Loading...' : userData.storeName}
            </div>
            <div className={styles.userEmail}>
              {userData.loading ? '' : userData.fullName}
            </div>
          </div>
        </div>

        {/* Logout Button */}
        <button 
          className={styles.logoutButton}
          onClick={handleLogout}
          disabled={isLoggingOut}
        >
          <span className={styles.logoutIcon}>🚪</span>
          <span className={styles.logoutText}>
            {isLoggingOut ? 'Logging out...' : 'Logout'}
          </span>
        </button>
      </div>
    </aside>
  );
}