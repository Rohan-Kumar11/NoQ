'use client'

import { useState } from 'react'
import { useRouter } from 'next/navigation'
import { motion, AnimatePresence } from 'framer-motion'
import { signIn, signUpCustomer, signUpBusiness, signInWithGoogle } from '@/lib/auth'
import Toast from './Toast'
import { useToast } from '../hooks/useToast'
import styles from './Getstarted.module.css'

export default function GetStarted() {
  const router = useRouter()
  const { toast, hideToast, success, error: showError } = useToast()
  const [isSignIn, setIsSignIn] = useState(true)
  const [userType, setUserType] = useState('customer') // 'customer' or 'business'
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')
  const [showVerificationDialog, setShowVerificationDialog] = useState(false)
  const [verificationEmail, setVerificationEmail] = useState('')
  const [formData, setFormData] = useState({
    fullName: '',
    email: '',
    company: '',
    phone: '',
    password: '',
    businessType: 'retail',
    address: '',
    preferredService: ''
  })
  const [focusedField, setFocusedField] = useState(null)

  const handleSubmit = async (e) => {
    e.preventDefault()
    setError('')
    setLoading(true)

    try {
      let result

      if (isSignIn) {
        // Sign In
        result = await signIn(formData.email, formData.password)
        
        if (result.success) {
          success('Welcome back! Redirecting to dashboard...')
          // Small delay to show the toast before redirect
          setTimeout(() => {
            router.push(result.redirectTo || '/signin')
          }, 1000)
        }
      } else {
        // Sign Up
        if (userType === 'customer') {
          result = await signUpCustomer({
            fullName: formData.fullName,
            email: formData.email,
            phone: formData.phone,
            password: formData.password,
            preferredService: formData.preferredService
          })
        } else {
          result = await signUpBusiness({
            fullName: formData.fullName,
            company: formData.company,
            email: formData.email,
            phone: formData.phone,
            password: formData.password,
            businessType: formData.businessType,
            address: formData.address
          })
        }

        if (result.success) {
          // Show verification dialog for sign up
          setVerificationEmail(formData.email)
          setShowVerificationDialog(true)
          success('Account created successfully! Check your email.')
        }
      }

      if (!result.success) {
        setError(result.error || 'An error occurred. Please try again.')
        showError(result.error || 'An error occurred. Please try again.')
      }
    } catch (err) {
      console.error('Form submission error:', err)
      const errorMessage = 'An unexpected error occurred. Please try again.'
      setError(errorMessage)
      showError(errorMessage)
    } finally {
      setLoading(false)
    }
  }

  const handleVerificationDialogClose = () => {
    setShowVerificationDialog(false)
    setVerificationEmail('')
    setIsSignIn(true) // Switch to sign in mode
    resetForm()
    success('You can now sign in after verifying your email!')
  }

  const handleGoogleSignIn = async () => {
    setError('')
    setLoading(true)

    try {
      const result = await signInWithGoogle()
      
      if (!result.success) {
        const errorMsg = result.error || 'Failed to sign in with Google'
        setError(errorMsg)
        showError(errorMsg)
      }
      // OAuth will redirect automatically, no need to handle success
    } catch (err) {
      console.error('Google sign in error:', err)
      const errorMsg = 'Failed to sign in with Google'
      setError(errorMsg)
      showError(errorMsg)
    } finally {
      setLoading(false)
    }
  }

  const handleChange = (e) => {
    setFormData({
      ...formData,
      [e.target.name]: e.target.value
    })
    // Clear error when user starts typing
    if (error) setError('')
  }

  const resetForm = () => {
    setFormData({
      fullName: '',
      email: '',
      company: '',
      phone: '',
      password: '',
      businessType: 'retail',
      address: '',
      preferredService: ''
    })
    setError('')
  }

  const handleModeSwitch = (mode) => {
    setIsSignIn(mode)
    resetForm()
  }

  const handleUserTypeSwitch = (type) => {
    setUserType(type)
    resetForm()
  }

  return (
    <div className={styles.container}>
      {/* Toast Notification */}
      <Toast
        message={toast.message}
        type={toast.type}
        isVisible={toast.isVisible}
        onClose={hideToast}
        duration={toast.duration}
      />

      {/* Animated Background */}
      <div className={styles.backgroundElements}>
        <motion.div
          className={styles.circle1}
          animate={{
            y: [0, -30, 0],
            x: [0, 20, 0],
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
        <motion.div
          className={styles.circle2}
          animate={{
            y: [0, 40, 0],
            x: [0, -30, 0],
          }}
          transition={{
            duration: 10,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
        <motion.div
          className={styles.circle3}
          animate={{
            scale: [1, 1.2, 1],
            opacity: [0.3, 0.5, 0.3],
          }}
          transition={{
            duration: 6,
            repeat: Infinity,
            ease: "easeInOut"
          }}
        />
      </div>

      {/* Main Content */}
      <div className={styles.contentWrapper}>
        {/* Left Side - Branding */}
        <motion.div
          className={styles.leftPanel}
          initial={{ opacity: 0, x: -50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
        >
          <div className={styles.leftPanelContent}>
            <motion.a
              href="/"
              className={styles.logo}
              whileHover={{ scale: 1.05 }}
            >
              No<span className={styles.logoAccent}>Q</span>
            </motion.a>

            <motion.h1
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.2 }}
            >
              Transform Your<br />
              <span className={styles.gradientText}>Customer Experience</span>
            </motion.h1>

            <motion.p
              className={styles.subtitle}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.4 }}
            >
              Join thousands of businesses eliminating queues and delighting customers with NoQ's intelligent queue management.
            </motion.p>

            {/* Features List */}
            <motion.div
              className={styles.featuresList}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 0.6 }}
            >
              {[
                { icon: '⚡', text: '5-minute setup' },
                { icon: '📊', text: 'Real-time analytics' },
                { icon: '🔒', text: 'Enterprise security' },
                { icon: '💰', text: '340% ROI in year one' }
              ].map((feature, i) => (
                <motion.div
                  key={i}
                  className={styles.featureItem}
                  initial={{ opacity: 0, x: -20 }}
                  animate={{ opacity: 1, x: 0 }}
                  transition={{ duration: 0.5, delay: 0.8 + i * 0.1 }}
                >
                  <span className={styles.featureIcon}>{feature.icon}</span>
                  <span>{feature.text}</span>
                </motion.div>
              ))}
            </motion.div>

            {/* Testimonial */}
            <motion.div
              className={styles.testimonial}
              initial={{ opacity: 0, y: 20 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.6, delay: 1.2 }}
            >
              <p className={styles.quote}>
                "NoQ reduced our customer wait times by 50% in the first month. Game-changing."
              </p>
              <p className={styles.author}>— Sarah Chen, VP Operations</p>
            </motion.div>
          </div>
        </motion.div>

        {/* Right Side - Form */}
        <motion.div
          className={styles.rightPanel}
          initial={{ opacity: 0, x: 50 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.8 }}
        >
          <div className={styles.formContainer}>
            {/* Toggle Buttons - Sign In / Sign Up */}
            <div className={styles.toggleContainer}>
              <button
                className={`${styles.toggleBtn} ${isSignIn ? styles.active : ''}`}
                onClick={() => handleModeSwitch(true)}
                disabled={loading}
              >
                Sign In
              </button>
              <button
                className={`${styles.toggleBtn} ${!isSignIn ? styles.active : ''}`}
                onClick={() => handleModeSwitch(false)}
                disabled={loading}
              >
                Sign Up
              </button>
              <motion.div
                className={styles.toggleIndicator}
                animate={{ x: isSignIn ? 0 : '100%' }}
                transition={{ type: "spring", stiffness: 300, damping: 30 }}
              />
            </div>

            {/* User Type Selection - Only for Sign Up */}
            {!isSignIn && (
              <motion.div
                className={styles.userTypeContainer}
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
                transition={{ duration: 0.3 }}
              >
                <button
                  className={`${styles.userTypeBtn} ${userType === 'customer' ? styles.active : ''}`}
                  onClick={() => handleUserTypeSwitch('customer')}
                  disabled={loading}
                >
                  <span className={styles.userTypeIcon}>👤</span>
                  <span>Customer</span>
                </button>
                <button
                  className={`${styles.userTypeBtn} ${userType === 'business' ? styles.active : ''}`}
                  onClick={() => handleUserTypeSwitch('business')}
                  disabled={loading}
                >
                  <span className={styles.userTypeIcon}>💼</span>
                  <span>Business</span>
                </button>
              </motion.div>
            )}

            {/* Form Header */}
            <motion.div
              className={styles.formHeader}
              key={`${isSignIn}-${userType}`}
              initial={{ opacity: 0, y: -10 }}
              animate={{ opacity: 1, y: 0 }}
              transition={{ duration: 0.4 }}
            >
              <h2>
                {isSignIn 
                  ? 'Welcome back' 
                  : userType === 'customer' 
                    ? 'Sign up as Customer' 
                    : 'Sign up as Business'}
              </h2>
              <p>
                {isSignIn
                  ? 'Sign in to your account' 
                  : userType === 'customer'
                  ? 'Create your free account'
                  : 'No credit card required • 14-day free trial'}
              </p>
            </motion.div>

            {/* Error Message */}
            {error && (
              <motion.div
                className={styles.errorMessage}
                initial={{ opacity: 0, y: -10 }}
                animate={{ opacity: 1, y: 0 }}
              >
                {error}
              </motion.div>
            )}

            {/* Social Sign In */}
            <div className={styles.socialButtons}>
              <motion.button
                className={styles.socialBtn}
                onClick={handleGoogleSignIn}
                disabled={loading}
                whileHover={{ y: -2 }}
                whileTap={{ scale: 0.98 }}
              >
                <svg width="20" height="20" viewBox="0 0 24 24" fill="currentColor">
                  <path d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z"/>
                  <path d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z"/>
                  <path d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l2.85-2.22.81-.62z"/>
                  <path d="M12 5.38c1.62 0 3.06.56 4.21 1.64l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z"/>
                </svg>
                Continue with Google
              </motion.button>
            </div>

            <div className={styles.divider}>
              <span>or</span>
            </div>

            {/* Form */}
            <AnimatePresence mode="wait">
              <motion.form
                key={`${isSignIn}-${userType}-form`}
                className={styles.form}
                onSubmit={handleSubmit}
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                exit={{ opacity: 0, y: -10 }}
                transition={{ duration: 0.3 }}
              >
                {/* Sign Up Forms */}
                {!isSignIn && (
                  <>
                    {/* Customer Sign Up */}
                    {userType === 'customer' && (
                      <>
                        <FormField
                          label="Full Name"
                          name="fullName"
                          type="text"
                          placeholder="John Doe"
                          value={formData.fullName}
                          onChange={handleChange}
                          focused={focusedField === 'fullName'}
                          onFocus={() => setFocusedField('fullName')}
                          onBlur={() => setFocusedField(null)}
                          icon="👤"
                          disabled={loading}
                        />

                        <FormField
                          label="Email Address"
                          name="email"
                          type="email"
                          placeholder="you@example.com"
                          value={formData.email}
                          onChange={handleChange}
                          focused={focusedField === 'email'}
                          onFocus={() => setFocusedField('email')}
                          onBlur={() => setFocusedField(null)}
                          icon="📧"
                          disabled={loading}
                        />

                        <FormField
                          label="Phone Number"
                          name="phone"
                          type="tel"
                          placeholder="+1 (555) 000-0000"
                          value={formData.phone}
                          onChange={handleChange}
                          focused={focusedField === 'phone'}
                          onFocus={() => setFocusedField('phone')}
                          onBlur={() => setFocusedField(null)}
                          icon="📱"
                          disabled={loading}
                        />

                        <FormField
                          label="Password"
                          name="password"
                          type="password"
                          placeholder="••••••••"
                          value={formData.password}
                          onChange={handleChange}
                          focused={focusedField === 'password'}
                          onFocus={() => setFocusedField('password')}
                          onBlur={() => setFocusedField(null)}
                          icon="🔒"
                          disabled={loading}
                        />
                      </>
                    )}

                    {/* Business Sign Up */}
                    {userType === 'business' && (
                      <>
                        <FormField
                          label="Full Name"
                          name="fullName"
                          type="text"
                          placeholder="John Doe"
                          value={formData.fullName}
                          onChange={handleChange}
                          focused={focusedField === 'fullName'}
                          onFocus={() => setFocusedField('fullName')}
                          onBlur={() => setFocusedField(null)}
                          icon="👤"
                          disabled={loading}
                        />

                        <FormField
                          label="Company Name"
                          name="company"
                          type="text"
                          placeholder="Acme Inc."
                          value={formData.company}
                          onChange={handleChange}
                          focused={focusedField === 'company'}
                          onFocus={() => setFocusedField('company')}
                          onBlur={() => setFocusedField(null)}
                          icon="🏢"
                          disabled={loading}
                        />

                        <FormField
                          label="Business Email"
                          name="email"
                          type="email"
                          placeholder="you@company.com"
                          value={formData.email}
                          onChange={handleChange}
                          focused={focusedField === 'email'}
                          onFocus={() => setFocusedField('email')}
                          onBlur={() => setFocusedField(null)}
                          icon="📧"
                          disabled={loading}
                        />

                        <FormField
                          label="Phone Number"
                          name="phone"
                          type="tel"
                          placeholder="+1 (555) 000-0000"
                          value={formData.phone}
                          onChange={handleChange}
                          focused={focusedField === 'phone'}
                          onFocus={() => setFocusedField('phone')}
                          onBlur={() => setFocusedField(null)}
                          icon="📱"
                          disabled={loading}
                        />

                        <FormField
                          label="Password"
                          name="password"
                          type="password"
                          placeholder="••••••••"
                          value={formData.password}
                          onChange={handleChange}
                          focused={focusedField === 'password'}
                          onFocus={() => setFocusedField('password')}
                          onBlur={() => setFocusedField(null)}
                          icon="🔒"
                          disabled={loading}
                        />

                        <div className={styles.formField}>
                          <label>Business Type</label>
                          <div className={styles.inputWrapper}>
                            <span className={styles.inputIcon}>🏪</span>
                            <select
                              name="businessType"
                              value={formData.businessType}
                              onChange={handleChange}
                              className={styles.selectWithIcon}
                              disabled={loading}
                            >
                              <option value="retail">Retail</option>
                              <option value="healthcare">Healthcare</option>
                              <option value="food-beverage">Food & Beverage</option>
                              <option value="government">Government</option>
                              <option value="banking">Banking</option>
                              <option value="hospitality">Hospitality</option>
                              <option value="other">Other</option>
                            </select>
                          </div>
                        </div>

                        <FormField
                          label="Business Address"
                          name="address"
                          type="text"
                          placeholder="123 Main St, City, State"
                          value={formData.address}
                          onChange={handleChange}
                          focused={focusedField === 'address'}
                          onFocus={() => setFocusedField('address')}
                          onBlur={() => setFocusedField(null)}
                          icon="📍"
                          disabled={loading}
                        />
                      </>
                    )}
                  </>
                )}

                {/* Sign In Form */}
                {isSignIn && (
                  <>
                    <FormField
                      label="Email Address"
                      name="email"
                      type="email"
                      placeholder="you@company.com"
                      value={formData.email}
                      onChange={handleChange}
                      focused={focusedField === 'email'}
                      onFocus={() => setFocusedField('email')}
                      onBlur={() => setFocusedField(null)}
                      icon="📧"
                      disabled={loading}
                    />

                    <FormField
                      label="Password"
                      name="password"
                      type="password"
                      placeholder="••••••••"
                      value={formData.password}
                      onChange={handleChange}
                      focused={focusedField === 'password'}
                      onFocus={() => setFocusedField('password')}
                      onBlur={() => setFocusedField(null)}
                      icon="🔒"
                      disabled={loading}
                    />

                    <div className={styles.forgotPassword}>
                      <a href="/forgot-password">Forgot password?</a>
                    </div>
                  </>
                )}

                <motion.button
                  type="submit"
                  className={styles.submitBtn}
                  disabled={loading}
                  whileHover={{ scale: loading ? 1 : 1.02 }}
                  whileTap={{ scale: loading ? 1 : 0.98 }}
                >
                  {loading ? (
                    <span className={styles.loadingSpinner}>
                      <svg className={styles.spinner} viewBox="0 0 50 50">
                        <circle cx="25" cy="25" r="20" fill="none" strokeWidth="5"></circle>
                      </svg>
                      {isSignIn ? 'Signing in...' : 'Creating account...'}
                    </span>
                  ) : (
                    <>
                      {isSignIn ? 'Sign In' : 'Start Free Trial'}
                      <span className={styles.btnArrow}>→</span>
                    </>
                  )}
                </motion.button>

                {!isSignIn && (
                  <p className={styles.terms}>
                    By signing up, you agree to our{' '}
                    <a href="#terms">Terms of Service</a> and{' '}
                    <a href="#privacy">Privacy Policy</a>
                  </p>
                )}

                {/* Switch to Sign In/Sign Up */}
                <div className={styles.switchMode}>
                  <p>
                    {isSignIn ? "Don't have an account? " : "Already have an account? "}
                    <button
                      type="button"
                      onClick={() => handleModeSwitch(!isSignIn)}
                      className={styles.switchModeBtn}
                      disabled={loading}
                    >
                      {isSignIn ? 'Sign up' : 'Sign in'}
                    </button>
                  </p>
                </div>
              </motion.form>
            </AnimatePresence>
          </div>
        </motion.div>
      </div>

      {/* Email Verification Dialog */}
      <AnimatePresence>
        {showVerificationDialog && (
          <>
            {/* Backdrop */}
            <motion.div
              className={styles.dialogBackdrop}
              initial={{ opacity: 0 }}
              animate={{ opacity: 1 }}
              exit={{ opacity: 0 }}
              onClick={handleVerificationDialogClose}
            />
            
            {/* Dialog */}
            <motion.div
              className={styles.dialogContainer}
              initial={{ opacity: 0, scale: 0.9, y: 20 }}
              animate={{ opacity: 1, scale: 1, y: 0 }}
              exit={{ opacity: 0, scale: 0.9, y: 20 }}
              transition={{ type: "spring", duration: 0.5 }}
            >
              <div className={styles.dialog}>
                {/* Icon */}
                <motion.div
                  className={styles.dialogIcon}
                  initial={{ scale: 0 }}
                  animate={{ scale: 1 }}
                  transition={{ delay: 0.2, type: "spring", stiffness: 200 }}
                >
                  <svg width="64" height="64" viewBox="0 0 64 64" fill="none">
                    <circle cx="32" cy="32" r="32" fill="#10B981" fillOpacity="0.1"/>
                    <path d="M32 16C23.16 16 16 23.16 16 32C16 40.84 23.16 48 32 48C40.84 48 48 40.84 48 32C48 23.16 40.84 16 32 16ZM32 44C25.37 44 20 38.63 20 32C20 25.37 25.37 20 32 20C38.63 20 44 25.37 44 32C44 38.63 38.63 44 32 44Z" fill="#10B981"/>
                    <path d="M40 26L28 38L24 34" stroke="#10B981" strokeWidth="3" strokeLinecap="round" strokeLinejoin="round"/>
                  </svg>
                </motion.div>

                {/* Content */}
                <h2 className={styles.dialogTitle}>Check Your Email</h2>
                <p className={styles.dialogMessage}>
                  We've sent a verification link to:
                </p>
                <p className={styles.dialogEmail}>{verificationEmail}</p>
                <p className={styles.dialogInstruction}>
                  Please click the link in the email to verify your account. Once verified, you can sign in.
                </p>

                {/* Info Box */}
                <div className={styles.dialogInfoBox}>
                  <span className={styles.infoIcon}>💡</span>
                  <p>Didn't receive the email? Check your spam folder or contact support.</p>
                </div>

                {/* Button */}
                <motion.button
                  className={styles.dialogButton}
                  onClick={handleVerificationDialogClose}
                  whileHover={{ scale: 1.02 }}
                  whileTap={{ scale: 0.98 }}
                >
                  Got it, take me to Sign In
                  <span className={styles.btnArrow}>→</span>
                </motion.button>
              </div>
            </motion.div>
          </>
        )}
      </AnimatePresence>
    </div>
  )
}

function FormField({ label, name, type, placeholder, value, onChange, focused, onFocus, onBlur, icon, disabled }) {
  return (
    <motion.div
      className={`${styles.formField} ${focused ? styles.focused : ''}`}
      initial={{ opacity: 0, y: 10 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3 }}
    >
      <label htmlFor={name}>{label}</label>
      <div className={styles.inputWrapper}>
        <span className={styles.inputIcon}>{icon}</span>
        <input
          id={name}
          name={name}
          type={type}
          placeholder={placeholder}
          value={value}
          onChange={onChange}
          onFocus={onFocus}
          onBlur={onBlur}
          disabled={disabled}
          required
        />
      </div>
    </motion.div>
  )
}