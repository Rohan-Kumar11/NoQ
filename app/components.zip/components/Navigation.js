'use client'

import { useState, useEffect } from 'react'
import { motion, useScroll, useTransform } from 'framer-motion'
import styles from './Navigation.module.css'

export default function Navigation() {
  const [isScrolled, setIsScrolled] = useState(false)
  const { scrollY } = useScroll()
  const backgroundColor = useTransform(
    scrollY,
    [0, 100],
    ['rgba(250, 250, 250, 0.0)', 'rgba(250, 250, 250, 0.95)']
  )

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 50)
    }
    window.addEventListener('scroll', handleScroll)
    return () => window.removeEventListener('scroll', handleScroll)
  }, [])

  const navVariants = {
    hidden: { y: -100, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        duration: 0.8,
        ease: [0.6, 0.05, 0.01, 0.9]
      }
    }
  }

  const linkVariants = {
    initial: { opacity: 0, y: -20 },
    animate: (i) => ({
      opacity: 1,
      y: 0,
      transition: {
        delay: 0.1 * i,
        duration: 0.5,
        ease: [0.6, 0.05, 0.01, 0.9]
      }
    })
  }

  return (
    <motion.header
      className={styles.header}
      style={{ backgroundColor }}
      variants={navVariants}
      initial="hidden"
      animate="visible"
    >
      <nav className={styles.nav}>
        <motion.div 
          className={styles.logo}
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          No<span className={styles.logoAccent}>Q</span>
        </motion.div>
        
        <ul className={styles.navLinks}>
          {['Features', 'How It Works', 'Impact', 'About'].map((item, i) => (
            <motion.li
              key={item}
              custom={i}
              variants={linkVariants}
              initial="initial"
              animate="animate"
            >
              <a href={`#${item.toLowerCase().replace(' ', '-')}`}>
                {item}
              </a>
            </motion.li>
          ))}
        </ul>

        <motion.a
          href="/get-started"
          className={styles.contactBtn}
          whileHover={{ scale: 1.05, y: -2 }}
          whileTap={{ scale: 0.95 }}
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ delay: 0.6, duration: 0.5 }}
        >
          Get Started
        </motion.a>
      </nav>
    </motion.header>
  )
}